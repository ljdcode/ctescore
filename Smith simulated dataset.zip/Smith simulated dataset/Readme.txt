We offer the data with .txt and .m files.
In the .txt file, the data should separate by a comma ",".


Example MATLAB code to see the data
To view the mean (across 50 "subjects") ground truth network:
imagesc(squeeze(mean(net)));

To get the matrix of all nodes' timeseries for just the first subject:
ts1=ts(1:Ntimepoints,:);