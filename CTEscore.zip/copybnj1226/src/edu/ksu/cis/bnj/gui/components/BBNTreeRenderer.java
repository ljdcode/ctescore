/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



/*
 * Created on Oct 21, 2003
 *
 * This file is part of Bayesian Network for Java (BNJ).
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package edu.ksu.cis.bnj.gui.components;

import java.awt.Component;
import java.util.Hashtable;

import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

import salvo.jesus.graph.visual.VisualVertex;
import edu.ksu.cis.bnj.bbn.BBNNode;
import edu.ksu.cis.kdd.util.Settings;

/**
 * @author Roby Joehanes
 */
public class BBNTreeRenderer extends DefaultTreeCellRenderer {
    protected Hashtable settings = Settings.getWindowSettings("MAIN"); // $NON-NLS-1$
    protected ImageIcon randomNodeIcon = (ImageIcon) settings.get("RandomTreeNode"); // $NON-NLS-1$
    protected ImageIcon decisionNodeIcon = (ImageIcon) settings.get("DecisionTreeNode"); // $NON-NLS-1$
    protected ImageIcon utilityNodeIcon = (ImageIcon) settings.get("UtilityTreeNode"); // $NON-NLS-1$
    protected ImageIcon evidenceNodeIcon = (ImageIcon) settings.get("EvidenceValueIcon"); // $NON-NLS-1$
    protected ImageIcon valueNodeIcon = (ImageIcon) settings.get("NormalValueIcon"); // $NON-NLS-1$
    protected ImageIcon graphIcon = (ImageIcon) settings.get("GraphIcon"); // $NON-NLS-1$

	public BBNTreeRenderer() {
		super();
        setLeafIcon(null);
        setOpenIcon(null);
        setClosedIcon(null);
	}

    @Override
	public Component getTreeCellRendererComponent(JTree tree, Object treeNode, boolean isSelected,
        boolean isExpanded, boolean isLeaf, int rowNum, boolean hasFocus) {

        super.getTreeCellRendererComponent(tree, treeNode, isSelected, isExpanded, isLeaf, rowNum, hasFocus);
        
        // Detect node type
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) treeNode;
        Object userObject = node.getUserObject();
        if (node.isRoot()) {
            setIcon(graphIcon);
        } else {
            if (userObject instanceof VisualVertex) {
                BBNNode bbnNode = (BBNNode) ((VisualVertex) userObject).getVertex();
                ImageIcon selectedIcon = null;
                if (bbnNode.isDecision()) {
                    selectedIcon = decisionNodeIcon;
                } else if (bbnNode.isUtility()) {
                    selectedIcon = utilityNodeIcon;
                } else {
                    selectedIcon = randomNodeIcon;
                }
                setIcon(selectedIcon);
            } else {
                DefaultMutableTreeNode parent = (DefaultMutableTreeNode) node.getParent();
                VisualVertex parentObject = (VisualVertex) parent.getUserObject();
                BBNNode bbnNode = (BBNNode) parentObject.getVertex();

                if (bbnNode.isEvidence() && bbnNode.getEvidenceValue().equals(userObject)) {
                    setIcon(evidenceNodeIcon);
                } else {
                    setIcon(valueNodeIcon);
                }
                return this;
            }
        }
        return this;
    }
}
