/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.bnj.bbn.learning.analysis;


import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import edu.ksu.cis.bnj.bbn.analysis.Analyzer;
import edu.ksu.cis.bnj.bbn.inference.InferenceResult;
import edu.ksu.cis.kdd.data.Attribute;
import edu.ksu.cis.kdd.data.Data;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.data.Tally;

/**
 * @author Roby Joehanes
 */
public class DataAnalyzer extends Analyzer {

    protected Data data;
    protected Tally tally;
    protected int attributeSize, dataSize;
    protected InferenceResult marginals;

    public DataAnalyzer(Data d) {
        setData(d);
    }

    public void setData(Data d) {
        data = d;
        marginals = null;
    }

    public InferenceResult getDataMarginals() {
        if (marginals != null) return marginals;
        marginals = new InferenceResult();
        tally = data.getTallyer(); // new Tally(tuples);

        List attrs = data.getAttributes();
        attributeSize = attrs.size();
        dataSize = tally.size();
        int index = 0;
        for (Iterator i = attrs.iterator(); i.hasNext(); index++) {
            Attribute attr = (Attribute) i.next();
            int arity = attr.getArity();
            Hashtable tbl = new Hashtable();
            List values = attr.getValues();
            for (int j = 0; j < arity; j++) {
                double t = tally.tally(index,j);
                tbl.put(values.get(j), new Double(t/dataSize));
            }
            marginals.put(attr.getName(), tbl);
        }
        return marginals;
    }

    @Override
	public String toString() {
        if (marginals == null) getDataMarginals();
        return marginals.toString();
    }

    public static void main(String[] args) {
        DataAnalyzer d = new DataAnalyzer(Table.load(args[0]));
        System.out.println(d.toString());
    }
}
