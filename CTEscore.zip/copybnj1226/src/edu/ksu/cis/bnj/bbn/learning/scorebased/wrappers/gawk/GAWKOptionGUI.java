/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.bnj.bbn.learning.scorebased.wrappers.gawk;




import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;

import edu.ksu.cis.bnj.bbn.learning.scorebased.k2.K2OptionGUI;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.util.gui.GUIUtil;
import edu.ksu.cis.kdd.util.gui.Optionable;


/**
 * @author Roby Joehanes
 *
 */
public class GAWKOptionGUI extends K2OptionGUI {
    protected JSpinner numPopulations, numGenerations;

    /**
     * @param o
     */
    public GAWKOptionGUI(Optionable o) {
        super(o);
    }

    /**
     * @param o
     * @param owner
     */
    public GAWKOptionGUI(Optionable o, JFrame owner) {
        super(o, owner);
    }

    @Override
	protected void init() {
        super.init();
        mainPanel.remove(orderListScrollPane);
        mainPanel.remove(orderingButton);
        mainPanel.remove(upButton);
        mainPanel.remove(downButton);

        Dimension dim = new Dimension(60,20);
        JLabel label = new JLabel("Number of generations");
        numGenerations = new JSpinner();
        numGenerations.setValue(new Integer(GAWK.defaultPopulationSize));
        numGenerations.setPreferredSize(dim);
        GUIUtil.gbAdd(mainPanel, label,       0,11,   1,1, 6,12,6,12,  GridBagConstraints.NONE, GridBagConstraints.WEST, 0.0, 0.0);
        GUIUtil.gbAdd(mainPanel, numGenerations, 1,11,   1,1, 6,12,6,12,  GridBagConstraints.NONE, GridBagConstraints.WEST, 0.0, 0.0);

        label = new JLabel("Number of populations");
        numPopulations = new JSpinner();
        numPopulations.setValue(new Integer(GAWK.defaultGenerations));
        numPopulations.setPreferredSize(dim);

        GUIUtil.gbAdd(mainPanel, label,       0,12,   1,1, 6,12,6,12,  GridBagConstraints.NONE, GridBagConstraints.WEST, 0.0, 0.0);
        GUIUtil.gbAdd(mainPanel, numPopulations, 1,12,   1,1, 6,12,6,12,  GridBagConstraints.NONE, GridBagConstraints.WEST, 0.0, 0.0);
    }

    @Override
	public void actionPerformed(ActionEvent evt) {
        Object source = evt.getSource();
        //if (source == numGenerations) {} else
        super.actionPerformed(evt);
    }

    /**
     * @see edu.ksu.cis.bnj.gui.GenericOptionGUI#applyOptions()
     */
    @Override
	protected void applyOptions() {
        GAWK gawk = (GAWK) optionableOwner;
        if (outputButton.isSelected()) {
            gawk.setOutputFile(outputFileText.getText());
        } else {
            gawk.setOutputFile(""); // $NON-NLS-1$
        }
        gawk.setCalculateRMSE(rmseButton.isSelected());
        gawk.setGenerations(((Integer) numGenerations.getValue()).intValue());
        gawk.setPopulationSize(((Integer) numPopulations.getValue()).intValue());
    }


    public static void main(String[] args){
        Table t = Table.load("examples/asia/asia1000data.arff");
        GAWK gawk = new GAWK(t);
        gawk.getOptionsDialog().setVisible(true);
    }
}
