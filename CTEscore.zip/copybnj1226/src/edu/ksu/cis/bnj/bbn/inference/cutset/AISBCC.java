/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */





package edu.ksu.cis.bnj.bbn.inference.cutset;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import edu.ksu.cis.bnj.bbn.BBNCPF;
import edu.ksu.cis.bnj.bbn.BBNDiscreteValue;
import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.BBNNode;
import edu.ksu.cis.bnj.bbn.inference.InferenceResult;
import edu.ksu.cis.bnj.bbn.inference.approximate.sampling.AIS;
import edu.ksu.cis.bnj.bbn.inference.ls.LS;

/**
 * @author Roby Joehanes
 */
//public class AISBCC extends ApproximateInference implements MCMCListener {
public class AISBCC {

    protected int aisUpdateFrequency = 20;
    protected BoundedCutset bcc;
    protected AIS ais;
    protected int updateCounter = 0;
    protected InferenceResult tempResult = null;
    private BBNGraph g;
    private int[] countArray;
    
	boolean runAIS = false;			// naive
	boolean runAISJoint = false;	// joint

    public AISBCC(){}

	/**
	 * @param g
	 */
	public AISBCC(BBNGraph g) {
		this.g = g;
	}

	/**
	 * @param g, runAIS, runAISJoint
	 */
	public AISBCC(BBNGraph g, boolean runAIS, boolean runAISJoint) {
		this.g = g;
		this.runAIS = runAIS;			// naive
		this.runAISJoint = runAISJoint;	// joint
	}
	
//	/**
//	 * @see edu.ksu.cis.bnj.bbn.inference.Inference#getMarginals()
//	 */
//	public InferenceResult getMarginals() {
//        bcc = new BoundedCutset(graph);
//        ais = new AIS(graph);
//        ais.addListener(this);
//
//        // To thread or not to thread, that is the question.
//        Thread t = new Thread(ais);
//        t.start();
//		return bcc.getMarginals();
//	}
//
//    /**
//     * @see edu.ksu.cis.bnj.bbn.inference.approximate.sampling.MCMCListener#callback(edu.ksu.cis.bnj.bbn.inference.approximate.sampling.MCMCEvent)
//     */
//    public Object callback(MCMCEvent event) {
//        updateCounter++;
//        if ((updateCounter % aisUpdateFrequency) != 0) return null;
//
//        tempResult = (InferenceResult) event.getTemporaryResult().clone();
//        tempResult.normalize();
//
//        TreeSet newSortedInst = new TreeSet();
//
//        synchronized (bcc.getLock()) {
////            TreeSet sortedInst = bcc.getSortedInstantiation();
////
////            // resort here
////            for (Iterator i = sortedInst.iterator(); i.hasNext(); ) {
////                JointProbEntry entry = (JointProbEntry) i.next();
////                JointProbEntry newEntry = new JointProbEntry(entry.key, rescoreEntry(entry.key));
////                newSortedInst.add(newEntry);
////            }
////
////            // replace the sorted instantiations
////            bcc.setSortedInstantiation(newSortedInst);
//        }
//
//        return newSortedInst;
//    }
//
//    protected double rescoreEntry(Hashtable entry) {
//        assert (tempResult != null && entry != null);
//        double p = 1.0;
//
//        for (Enumeration e = entry.keys(); e.hasMoreElements(); ) {
//            Object key = e.nextElement();
//            Object value = entry.get(key);
//            Hashtable tbl = (Hashtable) tempResult.get(key);
//            Double val = (Double) tbl.get(value);
//            if (val != null) {
//                p *= ((Double) val).doubleValue();
//            }
//        }
//
//        return p;
//    }

	/**
	 * @see edu.ksu.cis.bnj.bbn.inference.Inference#getName()
	 */
	public String getName() {
		return "AIS BCC Hybrid";
	}

	/**
	 * @return
	 */
	public int getAisUpdateFrequency() {
		return aisUpdateFrequency;
	}

	/**
	 * @param i
	 */
	public void setAisUpdateFrequency(int i) {
		aisUpdateFrequency = i;
	}
	
	public Hashtable getAISresult(Vector cutsetNodeNames, int numIterations) {
		Hashtable ht = new Hashtable();
		ais = new AIS(g, numIterations);		
		FileOutputStream outfile = null;
		String filename = "rmseplot.txt";
		
		// set up to print RMSE
		try {
			outfile = new FileOutputStream(filename);
			ais.setRMSEfile(outfile);
		}
		catch (IOException ioe) {
			System.out.println("error creating rmse file");
		}
		
        ais.generateData(true);
		InferenceResult result = ais.getMarginals();
		BBNCPF[] icpt = ais.getICPT();
		BBNNode[] nodes = ais.getNodes();
		Vector cutsetNodeValues = new Vector();
		
		// for each possible instantiation of cutsetNodeNames,
		// make a new entry in ht
		// its value will be the JOINT ICPT entry for that instantiation
		
		int numInstants = 1;
		
		for (int i = 0; i < cutsetNodeNames.size(); i++) {
			BBNNode node = (BBNNode) g.getNode(cutsetNodeNames.elementAt(i).toString());
			BBNDiscreteValue dval = (BBNDiscreteValue) node.getValues();
			cutsetNodeValues.addElement(dval);
			numInstants *= dval.size();
		}
		
		countArray = new int[cutsetNodeNames.size()];
		for (int i = 0; i < countArray.length; i++) {
			countArray[i] = 0;
		}
				
		if (runAIS) {
			for (int i = 0; i < numInstants; i++) {
				Hashtable retEntry = getNextInstant(cutsetNodeValues, cutsetNodeNames, i);
				double val = 1.0;
				Enumeration eenum = retEntry.keys();
				while (eenum.hasMoreElements()) {
					String singleNodeName = eenum.nextElement().toString();
					String value = retEntry.get(singleNodeName).toString();
					Hashtable singleEntry = new Hashtable();
					singleEntry.put(singleNodeName, value);
					for (int k = 0; k < nodes.length; k++) {
						BBNNode node = nodes[k];
						String nodeName = node.getName();
						if (nodeName.equals(singleNodeName)) {
							double queryVal = icpt[k].query(retEntry);
							int numICPTentries = icpt[k].getTable().size();
							int numNodeValues = ((BBNDiscreteValue) node.getValues()).size();
							queryVal /= (numICPTentries/numNodeValues);
							val *= queryVal;
						}
					}
				}
				ht.put(retEntry, new Double(val));
			}
		}
		else {	// runAISJoint
			LS ls = new LS(g);
			InferenceResult lsResult = ls.getMarginals();
			for (int i = 0; i < numInstants; i++) {
				Hashtable retEntry = getNextInstant(cutsetNodeValues, cutsetNodeNames, i);
				g.setEvidenceTable(retEntry);
				ais = new AIS(g);
				ais.generateData(true);
				result = ais.getMarginals();
				double rmse = lsResult.computeRMSE(result);
				ht.put(retEntry, new Double(rmse));
			}	
		}

		System.out.println(ht.toString());
		return ht;
	}
	
	private Hashtable getNextInstant(Vector values, Vector nodeNames, int iteration) {
		Hashtable ht = new Hashtable();
		int[] valueSizes = new int[values.size()];
		for (int i = 0; i < values.size(); i++) {
			BBNDiscreteValue dv = (BBNDiscreteValue) values.elementAt(i);
			valueSizes[i] = dv.size();
		}
		
		if (iteration != 0) {
		
			for (int i = 0; i < values.size(); i++) {
				if (countArray[i] < (valueSizes[i] - 1)) {
					countArray[i]++;
					for (int j = 0; j < i; j++) {
						countArray[j] = 0;
					}
					break;
				}
			}
		}
		
		//now return hashtable based on current countArray values
		for (int i = 0; i < values.size(); i++) {
			BBNDiscreteValue dv = (BBNDiscreteValue) values.elementAt(i);
			Iterator it = dv.iterator();
			int count = 0;
			String val = "";
			while (it.hasNext()) {
				val = it.next().toString();
				if (count == countArray[i]) {
					break;
				}
				count++;
			}
			ht.put(nodeNames.elementAt(i), val);
		}
		
		return ht;
	}
}