/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



/*
 * @author Julie Thornton
 *
 */
package edu.ksu.cis.bnj.test;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.BBNNode;
import edu.ksu.cis.kdd.util.Parameter;
import edu.ksu.cis.kdd.util.ParameterTable;

/**
 * @author Julie Thornton
 *
 */

public class TestStructureLearning {
	
	private BBNGraph goldGraph;
	private BBNGraph inputGraph;
	private int size;
	private int[][] goldstandard;
	private int[][] current;
	private Hashtable nameToIndex;
	
	public TestStructureLearning(BBNGraph gold, BBNGraph input) {
		goldGraph = gold;
		inputGraph = input;
		size = goldGraph.getNodes().size();
		goldstandard = new int[size][size];
		current = new int[size][size];
		nameToIndex = new Hashtable();
		
		Set nodes = goldGraph.getNodeNames();
		Iterator it = nodes.iterator();
		int count = 0;
		while (it.hasNext()) {
			String nodeName = it.next().toString();
			nameToIndex.put(nodeName, new Integer(count));
			count++;
		}
	}
	
	public int countGraphErrors() {
		Set nodes = goldGraph.getNodeNames();
		Iterator it = nodes.iterator();
		while (it.hasNext()) {
			String nodeName = it.next().toString();
			BBNNode goldNode = (BBNNode) goldGraph.getNode(nodeName);
			BBNNode curNode = (BBNNode) inputGraph.getNode(nodeName);
			addChildren(goldNode, true);
			addChildren(curNode, false);
		}
		
		int addErrors = countErrorAddition();
		int revErrors = countErrorReversal();
		int delErrors = countErrorDeletion();
		
		return addErrors + revErrors + delErrors;
	}
	
	private void addChildren(BBNNode node, boolean addToGold) {
		String nodeName = node.getName();
		int nodeIndex = ((Integer) nameToIndex.get(nodeName)).intValue();
		Set children = node.getChildrenNames();
		Iterator it = children.iterator();
		while (it.hasNext()) {
			String childName = it.next().toString();
			int childIndex = ((Integer) nameToIndex.get(childName)).intValue();
			if (addToGold) {
				goldstandard[nodeIndex][childIndex] = 1;
			}
			else {
				current[nodeIndex][childIndex] = 1;
			}
		}
	}
	
	private int countErrorAddition() {
		int count = 0;

		for (int i = 0; i < size; i++) {
			for (int j = i+1; j < size; j++) {
				if (current[i][j] + current[j][i] > goldstandard[i][j] + goldstandard[j][i]) {
					count++;
				}
			}
		}

		return count;
	}

	private int countErrorDeletion() {
		int count = 0;

		for (int i = 0; i < size; i++) {
			for (int j = i+1; j < size; j++) {
				if (current[i][j] + current[j][i] < goldstandard[i][j] + goldstandard[j][i]) {
					count++;
				}
			}
		}

		return count;
	}

	private int countErrorReversal() {
		int count = 0;

		for (int i = 0; i < size; i++) {
			for (int j = i+1; j < size; j++) {
				if ((current[i][j] == goldstandard[j][i] && goldstandard[j][i] == 1) || 
				    (current[j][i] == goldstandard[i][j] && goldstandard[i][j] == 1)) {
					count++;
				}
			}
		}

		return count;
	}

	public static void main(String[] args) {
		ParameterTable params = Parameter.process(args);
		String goldFile = params.getString("-g");
		String inputFile = params.getString("-i");

		if (inputFile == null || goldFile == null) {
			System.out.println("Usage: edu.ksu.cis.bnj.test.TestStructureLearning -g:goldFile -i:inputFile");
			return;
		}
		
		try {
			BBNGraph goldGraph = BBNGraph.load(goldFile);
			BBNGraph inputGraph = BBNGraph.load(inputFile);      
			
			TestStructureLearning tsl = new TestStructureLearning(goldGraph, inputGraph);
			int numGraphErrors = tsl.countGraphErrors();
			
			System.out.println("Graph errors: " + numGraphErrors);
			        
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
}
