/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



/*
 * Created on Mar 12, 2003
 *
 * This file is part of Bayesian Network for Java (BNJ).
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package edu.ksu.cis.kdd.ga;

import edu.ksu.cis.kdd.ga.operators.OXOp;
import edu.ksu.cis.kdd.util.FileClassLoader;
import edu.ksu.cis.kdd.util.MersenneTwisterFast;
import edu.ksu.cis.kdd.util.Settings;

/**
 * @author Roby Joehanes
 */
public abstract class GAOp {
    protected int operandSize = 1;
    protected final MersenneTwisterFast random = Settings.random;
    protected double rate = 0.5;

    static {
        assert OXOp.class != null;
    }
    /**
     * The GA Operator constructor
     * @param size The number of arguments (chromosomes) needed for this GA Operator
     */
    public GAOp(int size) {
        operandSize = size;
    }

    /**
     * @return double
     */
    public final double getRate() {
        return rate;
    }

    /**
     * Sets the rate.
     * @param rate The rate to set
     */
    public final void setRate(double rate) {
        this.rate = rate > 1.0 ? 1.0 : rate < 0.0 ? 0.0: rate;
    }

    public abstract Chromosome[] apply(final Chromosome[] ind);

    public final int getOperandSize() {
        return operandSize;
    }

    public void setOperandSize(int o) {
        operandSize = o;
    }

    public static GAOp loadOperator(String className) {
        try {
        	return (GAOp) FileClassLoader.loadAndInstantiate(className, GAOp.class.getName(), null);
        } catch (Exception e) {
            return null;
        }
    }
}
