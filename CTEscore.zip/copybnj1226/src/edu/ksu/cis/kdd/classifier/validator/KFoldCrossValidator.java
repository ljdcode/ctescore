/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.kdd.classifier.validator;

/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

import edu.ksu.cis.kdd.classifier.Statistics;
import edu.ksu.cis.kdd.data.Table;

/**
 * @author Roby Joehanes
 *
 */
public class KFoldCrossValidator extends Validator {
    protected int k = 10;
    protected int curK = 0;
    protected int bestK = -1;
    protected Statistics bestStat = null;

    public KFoldCrossValidator(int k)
    {
        this.k = k;
    }

	/**
	 * @see edu.ksu.cis.kdd.data.validator.Validator#getTestData()
	 */
	@Override
	public Table getTestData() {
        if (curK <= k)
        {
            Table test = owner.getTrainData();
            int size = test.size();
            return test.get((curK-1)*size/k, curK*size/k-1);
        }
        return owner.getTestData();
	}

	/**
	 * @see edu.ksu.cis.kdd.data.validator.Validator#getTrainData()
	 */
	@Override
	public Table getTrainData() {
        Table train = owner.getTrainData();
        int size = train.size();
        if (curK <= k)
		  return train.getAllExcept((curK-1)*size/k, curK*size/k-1);
        return train.getAllExcept((bestK-1)*size/k, bestK*size/k-1);
	}

	/**
	 * @see edu.ksu.cis.kdd.data.validator.Validator#hasNext()
	 */
	@Override
	public boolean hasNext() {
        if (curK == k)
        {
            owner.getStatistics().reset();
        } else if (curK == k +1)
        {
            owner.getStatistics().removeLastSubStatistics();
        }
		return curK <= k;
	}

	/**
	 * @see edu.ksu.cis.kdd.data.validator.Validator#init()
	 */
	@Override
	public void init() {
        assert owner != null;
        curK = 0; bestK = -1; bestStat = null;
	}

	/**
	 * @see edu.ksu.cis.kdd.data.validator.Validator#next()
	 */
	@Override
	public void next() {
        if (curK < k)
        {
            Statistics stat = owner.getStatistics().getLastSubStatistic();
            if ((stat != null) && (bestStat == null || stat.isBetterThan(bestStat)))
            {
                bestStat = stat; bestK = curK;
            }
        }
        curK++;
	}

}
