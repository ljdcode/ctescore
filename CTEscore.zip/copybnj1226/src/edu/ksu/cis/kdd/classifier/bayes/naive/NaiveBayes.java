/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.kdd.classifier.bayes.naive;

/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

import edu.ksu.cis.kdd.classifier.Classifier;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.data.Tuple;

/**
 * <P>Note: Please, this is a very very outdated Naive Bayes classifier. It starts as my
 * class project and it's been out of pace from the current infrastructure.
 * 
 * <P>Note to self: Update this when you have time. Improve performance by doing log instead
 * of simple logarithms.
 * 
 * <P>Note: This is for text classifier only!!! It can handle regular data but
 * it would be horribly inefficient.
 *  
 * @author Roby Joehanes
 */
public class NaiveBayes extends Classifier {

    protected Hashtable attrCounter = new Hashtable();
    protected Hashtable classAttrCounter = new Hashtable();

	/**
	 * @see edu.ksu.cis.kdd.data.Classifier#build(Table)
	 */
	@Override
	public Object build(Table tuples) {

        data = (Table) tuples.clone();
        tallyClassValues();

        // Simple frequency tallying
        for (Iterator i = data.getTuples().iterator(); i.hasNext(); )
        {
            Tuple t = (Tuple) i.next();
            Object classValue = new Double(t.getClassValue());
            Hashtable clsTable = (Hashtable) classAttrCounter.get(classValue);
            if (clsTable == null)
            {
                clsTable = new Hashtable();
                classAttrCounter.put(classValue, clsTable);
            }

            for (Iterator j = t.getValues().iterator(); j.hasNext(); )
            {
                Object val = j.next();
                if (classValue == val) continue;

                Hashtable valTable = (Hashtable) attrCounter.get(val);
                if (valTable == null)
                {
                    valTable = new Hashtable();
                    attrCounter.put(val,valTable);
                }
                Integer _i = (Integer) valTable.get(classValue);
                if (_i == null) _i = new Integer(0);
                valTable.put(classValue, new Integer(_i.intValue()+1));

                _i = (Integer) clsTable.get(val);
                if (_i == null) _i = new Integer(0);
                clsTable.put(val, new Integer(_i.intValue()+1));
            }
        }

        // Unused return value
		return null;
	}

	/**
	 * @see edu.ksu.cis.kdd.data.Classifier#classify(Tuple)
	 */
	@Override
	public Object classify(Tuple tuple) {
        assert data != null : "Classifier is not built yet!";

        Object v = null;
        double maxP = 0.0;

        Object clsValue = new Double(tuple.getClassValue());
        int size = getTupleSize();
        double pk = Math.log(1.0 / size);

        for (Enumeration j = classAttrCounter.keys(); j.hasMoreElements(); )
        {
            Object vj = j.nextElement();
            Hashtable clsTable = (Hashtable) classAttrCounter.get(vj);
            assert clsTable != null;
            Integer _i = (Integer) classCounter.get(vj);
            if (_i == null)
            {
                // It must be because of the lack of examples
                // So, skip
                continue;
            }
            double pv = Math.log(_i.intValue()) + pk; // P(v)
            double p = pv;

            for (Iterator i = tuple.getValues().iterator(); i.hasNext(); )
            {
                Object val = i.next();
                if (val == clsValue) continue;
                _i = (Integer) clsTable.get(val);

                // Just to make the code more readable
                double pa_v;  // P(a|v)
                if (_i == null)
                {
//                    pa_v = estimator.estimate(tuple, vj) * pk;
                    pa_v = -Math.log((tuple.getValues().size()-1 + attrCounter.size()));
                } else
                {
//                    pa_v = _i.intValue() * pk;
                    pa_v = Math.log((_i.intValue()+1.0) / (tuple.getValues().size()-1 + attrCounter.size()));
                }
                p += pa_v; // p = P(v) \Pi P(a_i|v_j)
            }
            if (p > maxP)
            {
                v = vj;
                maxP = p;
            }
        }
		return v;
	}

	/**
	 * Returns the attrCounter.
	 * @return Hashtable
	 */
	public Hashtable getAttributeTable() {
		return attrCounter;
	}

	/**
	 * Returns the classCounter.
	 * @return Hashtable
	 */
	public Hashtable getClassTable() {
		return classCounter;
	}

	/**
	 * Returns the data.
	 * @return Table
	 */
	@Override
	public Table getData() {
		return data;
	}

	/**
	 * Returns the attrCounter.
	 * @return Hashtable
	 */
	public Hashtable getAttrCounter() {
		return attrCounter;
	}

	/**
	 * Returns the classAttrCounter.
	 * @return Hashtable
	 */
	public Hashtable getClassAttrCounter() {
		return classAttrCounter;
	}

	/**
	 * @see edu.ksu.cis.kdd.data.Classifier#init()
	 */
	@Override
	public void init() {
        attrCounter = new Hashtable();
        classAttrCounter = new Hashtable();
	}

}
