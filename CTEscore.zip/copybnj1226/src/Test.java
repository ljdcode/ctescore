public class Test extends Depend {
	int j = 30;

	public Test() {   
		  j = 40;   
    print();   
    super.print();   
  
  }   
  @Override
void print() {   
    System.out.println("Target=> " + i);   
  }   
  public static void main(String[] args) {   
    Test target = new Test();   
  }   
}   

class Depend {   
  int i = 10;   
  
  public Depend() {   
    print();   
 i = 20;   
  }   
  
  void print() {   
    System.out.println("Depend=> " + this.i);   
  }   
}