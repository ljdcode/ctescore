
package bjut.ai.bn.score;

/**
 * <p>Title: MDLScore</p>
 *
 * <p>Description: ����MDLScore����</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import bjut.ai.bn.score.K2;
import bjut.ai.bn.learning.acob.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
public class MDLScore extends Score
{
	// ����Ϣ
	public static double maxMI;
	public static double minMI;
	public static double[][] Inf;
	public static int[][] ChiSquare;
	// record ʵ������ indexs Ҫ��ѯ�Ľڵ����飬���ز�ѯ���ΪHashMap
	public static PrintWriter out;

	public static int VEXNUM = 5;//��Ҫ��

	
	public static MDLScore INSTANCE = null;

	// �������
	public static int cacheCount = 0;// ����ĸ���
	public static int count = 0;// ���ü������
	public static int actualCalcCount = 0;
	public static TreeSet[] NodeInfo;

	public static enum TYPE {
		ORI, CI, CInew, HF, OP, AIO, SA, PC
	};

	private String[][] Records;
	private HashMap<String, Double> hm; // �м����                 //δ�õ�1
	public HashMap<String, Double> cacheResult;
	private int ri;       //δ�õ�2
	
	public static double[][] MDLArcScore;   //ÿһ���ߵ�mdl��
	
	public static MDLScore getMDLScore(String dir, int DatasetNum, int VexNum) {
	MDLScore.INSTANCE = new MDLScore(dir, DatasetNum, VexNum);
	MDLScore.VEXNUM = VexNum;
	
	return MDLScore.INSTANCE;
	 }


	 public MDLScore(String fileName, int size, int nodeNums) {
	 AlarmReader ar = new AlarmReader(fileName, size, nodeNums);
	 this.Records = ar.GetDataSet();
	 MDLScore.NodeInfo = ar.getColumnValue();
	 this.cacheResult = new HashMap<String, Double>();
	 }

	public String[][] getRecord() {
		return this.Records;
	}
	
	@Override
	public void clearCache() {
		System.out.println("�������");
		MDLScore.count = 0;
		MDLScore.cacheCount = 0;
		MDLScore.actualCalcCount = 0;
		this.cacheResult = new HashMap<String, Double>();
	}

	
	/**
	 * ��һ��ִ�еĺ���
	 * �����������֣�MDLScore��mdl ��Ϊ�ӿ��ð�
	 */
	@Override
	
	//K2
/*	public double calcScore(int index, ArrayList<Integer> parent) {

		// return this.calcMDLScoreBrutalCache(index, parent);
		return this.calcMDLScoreCache(index, parent);

	}*/
	
	//MDL
	
	 public void calcMDLArcScore()
    {
        System.out.println("����MDL");
        K2.MDLArcScore = new double[K2.VEXNUM][K2.VEXNUM];
        int row = 0;
        int col = 0;
        for (row = 0; row < K2.VEXNUM; row++)
        {
            for (col = 0; col < K2.VEXNUM; col++)
            {
                //����������
                if (row != col)
                {
                    //
                    ArrayList arr = new ArrayList();
                    arr.add(col);
                    MDLArcScore[row][col] =K2.INSTANCE.calcMDLUseArrayCache(row,arr);
                    System.out.println("����MDL:"+"row:"+row+"col"+col+MDLArcScore[row][col]);
                }
            }
        }

    }
	
	public double calcScore(int index, ArrayList<Integer> parent) {

		// return this.calcMDLScoreBrutalCache(index, parent);
	//	System.out.println("����MDL");
		return this.calcMDLUseArray(index, parent);

	}
	

	/*
	public double calcMDLScoreCache(int index, ArrayList<Integer> parent) {
		double result = 0.0;
		int[] indexArray = new int[parent.size() + 1];
		for (int i = 0; i < parent.size(); i++) {
			indexArray[i + 1] = parent.get(i);
		}
		Arrays.sort(indexArray);
		indexArray[0] = index;
		String indexString = this.convertToString(indexArray);
		if (this.cacheResult.containsKey(indexString)) {
			result = this.cacheResult.get(indexString);
			MDLScore.cacheCount++;
		} else {
			
			result = this.calcMDLScoreTool(index, indexArray);
			this.cacheResult.put(indexString, result);
		}
		return result;
	}

	* �ڶ���ִ�еĺ���*/

	

	/**
	 * ת��int[]Ϊ�����ַ���
	 * 
	 * @param array
	 *            int[]
	 * @return String
	 */
	private String convertToString(int[] array) {
		StringBuilder sb = new StringBuilder();
		for (int k : array) {
			sb.append(k);
			sb.append(",");
		}
		return sb.toString();
	}

	public static PrintWriter getPrinWriter(String filename) throws IOException {
		File dir = new File("c:" + File.separator + "BayesianLog_Alarm_mdl");
		dir.mkdir();
		File file = new File(dir, filename + ".csv");
		return new PrintWriter(new FileWriter(file, false));
	}

	private String convertToString(ArrayList<Integer> al) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0, size = al.size(); i < size; i++) {
			sb.append(al.get(i));
			sb.append(",");
		}
		return sb.toString();
	}



	/**
	 * ����log(n!)
	 * 
	 * @param n
	 *            int
	 * @return double
	 */
	private static double calcLog(int n) {
		double result = 0;
		for (int i = 1; i <= n; i++) {
			result = result + java.lang.Math.log10(i);
		}
		return result;
	}

	/**
	 * log2
	 * 
	 * @param value
	 *            double
	 * @return double
	 */
	public static double log2(double value) {
		return Math.log(value) / Math.log(2);

	}



	/**
	 * ������ѯ���У���ѯ������ϳ��ֵĴ���
	 * 
	 * @param record
	 *            String[][] ���������
	 * @param indexs
	 *            int[] Ҫ��ѯ�Ľڵ�����
	 * @return HashMap ��ѯ���
	 */
	private static HashMap getCount(String[][] record, int[] indexs) {
		HashMap hm = new HashMap();
		StringBuilder sb;
		Object tempcount;
		for (int i = 0; i < record.length; i++) {
			sb = new StringBuilder();
			for (int j = 0; j < indexs.length; j++) {

				sb.append(record[i][indexs[j]]);
				sb.append(";");
			}
			String temp = sb.toString();
			int count = 0;
			if ((tempcount = hm.get(temp)) != null) {
				count = (Integer) tempcount;
			}
			hm.put(temp, ++count);
		}
	//	 System.out.println("��ѯ�ڵ�");
		// for (int k : indexs)
		// System.out.print(k + ",");
		// System.out.println("");
		// System.out.println(hm);
		return hm;
	}//go

	/**
	 * indexs ��ѯ�Ľڵ�����飬�������� ��������
	 * 
	 * @param record
	 *            String[][]
	 * @param indexs
	 *            int[]
	 * @return int[]
	 */
	public static int[] getCountBrutal(String[][] record, int[] indexs) {
		// ��ʼ���������
		int resultLength = 1;
		for (int i = 0; i < indexs.length; i++) {
			int size = NodeInfo[indexs[i]].size();
			resultLength = resultLength * size;
		}
		// System.out.println("\n��ѯ���鳤��"+indexs.length);
		int[] result = new int[resultLength];
		for (int j = 0; j < record.length; j++) {					
			int[] temp = new int[indexs.length];
			for (int k = 0; k < indexs.length; k++) {
				temp[k] = Integer.parseInt(record[j][indexs[k]]);
				System.out.println(temp[k]);
			}
			int index = MDLScore.calcStringToIndex(temp, indexs);
			 System.out.println("\n��ѯ���鳤��"+resultLength+"|"+"����ֵ"+index);
			
			result[index-j]++;
		}
		return result;
	}

	/**
	 * 
	 * @param array
	 *            int[]
	 * @return int
	 */
	private static int calcStringToIndex(int[] array, int[] indexs) {
		int index = 0;
		for (int i = 0; i < array.length; i++) {
			int temp = 1;
			for (int j = i + 1; j < array.length; j++) {
				temp = temp * NodeInfo[indexs[j]].size();
			}
			index = index + array[i] * temp;
		}

		return index;
	}



	public static double getRefect(double ori) {
		return (ori - MDLScore.minMI) / (MDLScore.maxMI - MDLScore.minMI);
	}


	public static BNGraph[] b = new BNGraph[2];

	private double CalcMDLPart1(int index, ArrayList<Integer> parent) {
		
		double d = 0;
		d = (MDLScore.log2(this.Records.length) * 0.9) / 2;
		// d = 5.85;
		// d = Math.ceil(d);
		int vi = NodeInfo[index].size();
		double part1 = parent.size() * MDLScore.log2(MDLScore.VEXNUM);
		
		double part2 = 0;
		Iterator it = parent.iterator();
		if (parent.size() > 0) {
			part2 = 1.0;
			while (it.hasNext()) {
				int ParentNode = (Integer) it.next();
				int vj = NodeInfo[ParentNode].size();
				part2 *= (vj);
			}
		}
		// System.out.println(d+" "+vi+" "+part2+"ss"+parent.size());
		//return d * vi * part2;
	 return part1 + d *(vi-1) * part2;
	}

	private double CalcMDLPart2(int index, ArrayList<Integer> parent) {
		// ȡ�ó�ʼ����
		int qi = 1;
		// int ri = NodeInfo[index].size();
		double result2 = 0;

		// ȡ�ò�ѯ����
		int[] indexArray = new int[parent.size() + 1];
	//	System.out.println(parent.hashCode()+"s"+parent.size());
		for (int i = 0; i < parent.size(); i++) {
			indexArray[i + 1] = parent.get(i);
		//	System.out.println(indexArray[i + 1]);
		}
		Arrays.sort(indexArray);
		indexArray[0] = index;
		// ȡ�ò�ѯ���
		 
		int[] countResult = MDLScore.getCountBrutal(this.Records, indexArray);

		for (int count = 0; count < parent.size(); count++) {
			qi = qi * NodeInfo[parent.get(count)].size();
		}
		double[] NijkArray = new double[qi];
		// ���Nij
		for (int i = 0; i < NijkArray.length; i++) {
			int step = 0;
			for (int j = 0; j < NodeInfo[index].size(); j++) {
				NijkArray[i] += countResult[i + step];
				step += qi;
			}
		}
		double[] NijArray = new double[NodeInfo[index].size() * qi];
		int pos1 = 0;
		int pos2 = 0;
		for (int i = 0; i < NodeInfo[index].size(); i++) {
			System.arraycopy(NijkArray, pos1, NijArray, pos2, NijkArray.length);
			pos2 += qi;
		}
		
		for (int i = 0; i < countResult.length; i++) {
			if (countResult[i] != 0) {
				double para = NijArray[i] / countResult[i];
				// System.out.println(para);
				double TempLog = MDLScore.log2(para);
				double TempResult = countResult[i] * TempLog;
				// System.out.println(TempResult);
				result2 += TempResult;
			}
			// System.out.println(result2);
		}
		return result2;
	}

	/**
	 * ����MDL���֣�Ӧ�������ѯ��
	 * 
	 * @param index
	 *            int
	 * @param parent
	 *            ArrayList
	 * @return double
	 */
	public double calcMDLUseArray(int index, ArrayList<Integer> parent) {
	//	System.out.println(parent.hashCode()+"s"+parent.size());
		double part1 = this.CalcMDLPart1(index, parent);
	
	//	double part2 = this.CalcMDLPart2(index, parent);

		double result = -(part1);
	//	double result = -(part2 + part1);
		// System.out.println(" " +part1+" , " + part2 + " = " + result);
		return result;
	}


	/**
	 * �������Ĳ�ѯ����У�ȡ�õ�ǰ��ѯ����ĸ�ĸ�ڵ��key��
	 */
	public String getPareKey(String key) {
		int pos = key.indexOf(";");
		String parentKey = key.substring(pos + 1, key.length());
		return parentKey;
	}

	public boolean isDataMiss(String[] data, ArrayList<Integer> index) {
		boolean tag = false;
		for (int i = 0; i < index.size(); i++) {
			if (data[i].equals("?"))
				tag = true;
		}
		return tag;
	}
	
	@Override
	public double calcGraphScore(BNGraph g) {
		double score = 0.0;
		double size = g.getVexNum();
		for (int i = 0; i < size; i++) {
			ArrayList parent = g.GetNode(i).GetParentNodesIndex();
			double nodescore = this.calcScore(i, parent);
			score += nodescore;
		}
		
		return score;
		
	}
	

	/**
	 * ������
	 */
	public static void main(String[] args) {
		try {

			/*
			BNGraph g = BNGraph.GetGraphStandAlarm();
			BNGraph g2= BNGraph.GetGraphfromfile("F:\\data-b\\net\\g5-1.txt",5);
			BNGraph g3= BNGraph.GetGraphfromfile("F:\\data-b\\net\\g5-2.txt",5);
			
			Score MDLScore = new MDLScore("F:\\data-b\\sim1-4.txt", 10000, 5);
			// Score MDLScore = new MDLScore("data\\alarmstring.txt", 3000, 37);
			double score = MDLScore.calcGraphScore(g);
		    System.out.println(score);
		    
		    double score2 = MDLScore.calcGraphScore(g2);
		    double score3 = MDLScore.calcGraphScore(g3);
		    System.out.println(score2+" "+score3);*/
			
			BNGraph g = BNGraph.GetGraphStandAlarm();
			Score MDLScore = new MDLScore("F:\\data-t\\sim1.txt", 10000, 5);

			double score = MDLScore.calcGraphScore(g);
	        System.out.println("��׼ͼBIC����Ϊ��"+score);
	        

		BNGraph g2 = BNGraph.GetGraph2();
	    double score2 = MDLScore.calcGraphScore(g2);
	    System.out.println("ͼ1BIC����Ϊ��"+score2);
	    
		BNGraph g3 = BNGraph.GetGraph1();
	    double score1 = MDLScore.calcGraphScore(g3);
	    System.out.println("ͼ2BIC����Ϊ��"+score1);
		    

		   
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}
