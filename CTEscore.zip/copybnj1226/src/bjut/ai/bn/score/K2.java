
package bjut.ai.bn.score;

/**
 * <p>Title: K2</p>
 *
 * <p>Description: ����K2����</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.HillClimbing;
import bjut.ai.bn.learning.acob.AlarmReader;

import org.apache.commons.math3.special.Gamma;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class K2 extends Score {
    // ����Ϣ
    public static double maxMI;
    public static double minMI;
    public static double[][] Inf;
    public static int[][] ChiSquare;
    // record ʵ������ indexs Ҫ��ѯ�Ľڵ����飬���ز�ѯ���ΪHashMap
    public static PrintWriter out;
//	public static int VEXNUM = 37; // alarm 37, insurance 27,HailFinder 56
    // ,child 20 ,barley 48

    public static int VEXNUM = 5;//��Ҫ��
    //  public static int VEXNUM = 12;//��Ҫ��


    public static K2 INSTANCE = null;

    // �������
    public static int cacheCount = 0;// ����ĸ���
    public static int count = 0;// ���ü������
    public static int actualCalcCount = 0;
    public static TreeSet[] NodeInfo;

    public static enum TYPE {
        ORI, CI, CInew, HF, OP, AIO, SA, PC
    }

    ;

    private String[][] Records;
    private HashMap<String, Double> hm; // �м����
    public HashMap<String, Double> cacheResult;
    private int ri;

    public static K2 getK2(String dir, int DatasetNum, int VexNum) {
        K2.INSTANCE = new K2(dir, DatasetNum, VexNum);
        K2.VEXNUM = VexNum;

        return K2.INSTANCE;
    }


    public K2(String fileName, int size, int nodeNums) {
        AlarmReader ar = new AlarmReader(fileName, size, nodeNums);
        this.Records = ar.GetDataSet();
        K2.NodeInfo = ar.getColumnValue();
        this.cacheResult = new HashMap<String, Double>();
    }


    public String[][] getRecord() {
        return this.Records;
    }

    @Override
    public void clearCache() {
        System.out.println("�������");
        K2.count = 0;
        K2.cacheCount = 0;
        K2.actualCalcCount = 0;
        this.cacheResult = new HashMap<String, Double>();
    }

    /**
     * ����K2���ֺ��� calcK2(0,{1,2,3})û�л���
     *
     * @param index  int ��ǰ�ڵ�
     * @param parent int[] index�ĸ�ĸ�ڵ� �밴��Ȼ˳������
     * @return double �������ֺ���ֵ
     */
    public double calcK2(int index, ArrayList<Integer> parent1) {
        int[] parent = new int[parent1.size()];
        int temp = 0;
        while (temp < parent1.size()) {
            parent[temp] = parent1.get(temp);
            temp++;
        }
        // Arrays.sort(parent);
        // ȡ�ò�ѯ���
        int[] temp_parent = new int[parent.length + 1];
        System.arraycopy(parent, 0, temp_parent, 1, parent.length);
        temp_parent[0] = index;
        // Arrays.sort(temp_parent);
        ri = NodeInfo[index].size();
        // ����ڶ�����
        hm = K2.getCount(this.Records, temp_parent);
        double ijk_result = this.calcPart2(hm);
        // System.out.println("�ڶ�����=" + ijk_result);

        // �����һ����
        hm = K2.getCount(Records, parent); // ȡ��Nij
        double ij_result = this.calcPart1(hm);
        // System.out.println(Arrays.asList(hm));
        // System.out.println("��һ����=" + ij_result);
        double result = ij_result + ijk_result;
        return result;
    }


    /**
     * �����
     *
     * @param index  int
     * @param parent ArrayList
     * @return double
     * <p>
     * ԭ��calcK2Cache
     */
    public double calcK2Cache(int index, ArrayList<Integer> parent) {
        double result = 0.0;
        int[] indexArray = new int[parent.size() + 1];
        for (int i = 0; i < parent.size(); i++) {
            indexArray[i + 1] = parent.get(i);
        }
        Arrays.sort(indexArray);
        indexArray[0] = index;
        String indexString = this.convertToString(indexArray);
        if (this.cacheResult.containsKey(indexString)) {
            result = this.cacheResult.get(indexString);
            K2.cacheCount++;
        } else {

            result = this.calcK2Tool(index, indexArray);
            //	result =this.calcMDLUseArray(index, parent);


            this.cacheResult.put(indexString, result);
        }
        return result;
    }

    /**
     * @param index int
     * @param al    ArrayList
     * @return double
     */
    private double calcK2Brutal(int index, ArrayList<Integer> al) {

        // ȡ�ó�ʼ����
        int qi = 1;
        int ri = NodeInfo[index].size();
        double result = 0;

        // ȡ�ò�ѯ����
        int[] allNodes = new int[al.size() + 1];
        for (int k = 0; k < al.size(); k++) {
            allNodes[k + 1] = al.get(k);
        }
        allNodes[0] = index;
        // ȡ�ò�ѯ���
        int[] countResult = K2.getCountBrutal(this.Records, allNodes);
        for (int count = 0; count < al.size(); count++) {
            qi = qi * NodeInfo[al.get(count)].size();
        }
        // ��ʼ����
        int step = qi;
        for (int i = 0; i < qi; i++) {
            int Nij = 0;
            int Nijk = 0;
            // ����ڶ�����
            double result2 = 0;
            int point = 0;
            for (int j = 0; j < ri; j++) {
                Nijk = countResult[i + point];
                result2 = result2 + K2.calcLog(Nijk);
                Nij = Nij + Nijk;
                point = point + step;
            }
            // �����һ����
            double temp1 = K2.calcLog(ri - 1);
            double temp2 = K2.calcLog(Nij + ri - 1);
            double result1 = temp1 - temp2;
            result = result + result1 + result2;
        }

        return result;
    }

    /**
     * ������Ϊ�˷������mdl ԭ��calcK2BrutalCache ����k2��ѡ����
     *
     * @param index  int
     * @param parent ArrayList
     * @return double
     */
    public double calcK2BrutalCache(int index, ArrayList<Integer> parent) {
        K2.count++;
        double result = 0.0;
        int[] indexArray = new int[parent.size() + 1];
        for (int i = 0; i < parent.size(); i++) {
            indexArray[i + 1] = parent.get(i);
        }
        Arrays.sort(indexArray);
        indexArray[0] = index;

        String indexString = this.convertToString(indexArray);
        if (this.cacheResult.containsKey(indexString)) {
            result = this.cacheResult.get(indexString);
            K2.cacheCount++;
        } else {
            result = this.calcK2Brutal(index, parent);
            this.cacheResult.put(indexString, result);
            K2.actualCalcCount++;
        }
        return result;

    }

    /**
     * ת��int[]Ϊ�����ַ���
     *
     * @param array int[]
     * @return String
     */
    private String convertToString(int[] array) {
        StringBuilder sb = new StringBuilder();
        for (int k : array) {
            sb.append(k);
            sb.append(",");
        }
        return sb.toString();
    }

    public static PrintWriter getPrinWriter(String filename) throws IOException {
        File dir = new File("c:" + File.separator + "BayesianLog_Alarm_mdl");
        dir.mkdir();
        File file = new File(dir, filename + ".csv");
        return new PrintWriter(new FileWriter(file, false));
    }

    private String convertToString(ArrayList<Integer> al) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0, size = al.size(); i < size; i++) {
            sb.append(al.get(i));
            sb.append(",");
        }
        return sb.toString();
    }

    private double calcPart1(HashMap h1) // ij
    {
        // System.out.println("�����һ����ʱ��getCount��ϣ��\n" + h1);
        double ij_result = 0;
        Collection c = h1.values();
        Iterator it = c.iterator();
        while (it.hasNext()) {
            int Nij = (Integer) it.next();
            double temp1 = K2.calcLog(ri - 1);
            double temp2 = K2.calcLog(Nij + ri - 1);
            double temp3 = temp1 - temp2;
            ij_result = ij_result + temp3;
        }
        c = null;
        it = null;
        return ij_result;
    }

    private double calcPart2(HashMap h2) // ijk
    {
        // System.out.println("����ڶ�����ʱ��getCount��ϣ��\n" + h2);

        double ijk_result = 0;
        Collection c = h2.values();
        Iterator it = c.iterator();
        while (it.hasNext()) {
            int temp_k = (Integer) it.next();
            double temp_result = K2.calcLog(temp_k);
            ijk_result = ijk_result + temp_result;
        }
        c = null;
        it = null;
        return ijk_result;
    }

    /**
     * ����log(n!)
     *
     * @param n int
     * @return double
     */
    private static double calcLog(int n) {
        double result = 0;
        for (int i = 1; i <= n; i++) {
            result = result + java.lang.Math.log10(i);
        }
        return result;
    }

    /**
     * log2
     *
     * @param value double
     * @return double
     */
    public static double log2(double value) {
        return Math.log(value) / Math.log(2);

    }

    /**
     * �ڲ�ʹ��
     *
     * @param index     int
     * @param parentIJK int[]
     * @return double
     */
    private double calcK2Tool(int index, int[] parentIJK) {
        int[] parent = new int[parentIJK.length - 1];
        //AlarmReader ar = new AlarmReader("E:\\NEWS\\te5-50.txt", 5, 5);
        //	double[][] t=strtodouble(ar.GetDataSet()); //��ȡ������
        System.arraycopy(parentIJK, 1, parent, 0, parent.length);

        ri = NodeInfo[index].size();
        // ����ڶ�����
        hm = K2.getCount(this.Records, parentIJK);
        double ijk_result = this.calcPart2(hm);
        // System.out.println("�ڶ�����=" + ijk_result);

        // �����һ����
        hm = K2.getCount(Records, parent); // ȡ��Nij
        double ij_result = this.calcPart1(hm);
        // System.out.println("��һ����=" + ij_result);
        double result = ij_result + ijk_result;
        return result;

    }

    /**
     * ������ѯ���У���ѯ������ϳ��ֵĴ���
     *
     * @param record String[][] ���������
     * @param indexs int[] Ҫ��ѯ�Ľڵ�����
     * @return HashMap ��ѯ���
     */
    private static HashMap getCount(String[][] record, int[] indexs) {
        HashMap hm = new HashMap();
        StringBuilder sb;
        Object tempcount;
        for (int i = 0; i < record.length; i++) {
            sb = new StringBuilder();
            for (int j = 0; j < indexs.length; j++) {

                sb.append(record[i][indexs[j]]);
                sb.append(";");
            }
            String temp = sb.toString();
            int count = 0;
            if ((tempcount = hm.get(temp)) != null) {
                count = (Integer) tempcount;
            }
            hm.put(temp, ++count);
        }
        // System.out.println("��ѯ�ڵ�");
        // for (int k : indexs)
        // System.out.print(k + ",");
        // System.out.println("");
        // System.out.println(hm);
        return hm;
    }

    /**
     * indexs ��ѯ�Ľڵ�����飬�������� ��������
     *
     * @param record String[][]
     * @param indexs int[]
     * @return int[]
     */
    public static int[] getCountBrutal(String[][] record, int[] indexs) {
        // ��ʼ���������
        int resultLength = 1;
        for (int i = 0; i < indexs.length; i++) {
            int size = NodeInfo[indexs[i]].size();
            resultLength = resultLength * size;
        }
        // System.out.println("\n��ѯ���鳤��"+resultLength);
        int[] result = new int[resultLength];
        for (int j = 0; j < record.length; j++) {
            int[] temp = new int[indexs.length];
            for (int k = 0; k < indexs.length; k++) {
                temp[k] = Integer.parseInt(record[j][indexs[k]]);
            }
            int index = K2.calcStringToIndex(temp, indexs);
            // System.out.println("����ֵ"+index);
            // for(int c : temp)
            // System.out.print(c+",");
            result[index]++;
        }
        // for (int i : result)
        // {
        // if(i !=0)
        // System.out.print(i + ",");
        //
        // }
        return result;
    }

    /**
     * @param array int[]
     * @return int
     */
    private static int calcStringToIndex(int[] array, int[] indexs) {
        int index = 0;
        for (int i = 0; i < array.length; i++) {
            int temp = 1;
            for (int j = i + 1; j < array.length; j++) {
                temp = temp * NodeInfo[indexs[j]].size();
            }
            index = index + array[i] * temp;
        }

        return index;
    }

    /**
     * for test only
     */

    public void testspeed() {
        double[][] temp1 = new double[37][37];
        ArrayList<Integer> anodelist = null; // ��ʱ
        System.out.println("��ʼ��������Ϣ����");

        long start = System.currentTimeMillis();
        for (int i = 0; i < K2.VEXNUM; i++)
            for (int j = 0; j < K2.VEXNUM; j++) {
                if (i != j) {
                    anodelist = new ArrayList<Integer>();
                    anodelist.add(j);
                    temp1[i][j] = K2.INSTANCE.calcK2Brutal(i, anodelist)
                            - K2.INSTANCE.calcK2Brutal(i,
                            new java.util.ArrayList());
                } else
                    temp1[i][j] = Double.NEGATIVE_INFINITY;
            }
        long end = System.currentTimeMillis();
        CommonTools.outArray(temp1);
        System.out.format("���,����[%d]����\n", end - start);
    }


    // �����Բ��Բ���

    /**
     * ���㻥��Ϣ
     */
    public static void calcInf(String[][] data) {
        System.out.println("���㻥��Ϣ");
        K2.Inf = new double[K2.VEXNUM][K2.VEXNUM];
        int row = 0;
        int col = 0;
        for (row = 0; row < K2.VEXNUM; row++) {
            for (col = 0; col < K2.VEXNUM; col++) {
                // ����������
                if (row < col) {
                    //
                    Inf[row][col] = K2.calcInd(row, col, data);
                } else {
                    Inf[row][col] = Inf[col][row];
                }
            }
        }
        K2.maxMI = K2.getMaxMI();
        K2.minMI = K2.getMinMI();
    }

    /**
     * @param n int
     * @return double
     */
    private static double getChiSquare(int n) {
        // n ���ɶ� ����鿨������
        // �� = 0.005

        double[] chi = {7.879, 10.597, 12.838, 14.860, 16.750, 18.548, 20.278,
                21.955, 23.589, 25.188, 26.757, 28.299, 29.819, 31.319, 32.801,
                34.267, 35.718, 37.156, 38.582};


        return chi[n - 1];

    }

    /**
     * �����Բ���
     */
    public static void CITest(String[][] data) {
        System.out.println("����X������");
        K2.ChiSquare = new int[K2.VEXNUM][K2.VEXNUM];
        int arcToRemove = 0;
        for (int i = 0; i < K2.VEXNUM; i++) {
            for (int j = 0; j < K2.VEXNUM; j++) {
                if (i == j) {
                    continue;
                }
                double t = 2 * data.length * K2.Inf[i][j];
                int DegOfFreeDom = (K2.NodeInfo[i].size() - 1)
                        * (K2.NodeInfo[j].size() - 1);
                double valueChi = K2.getChiSquare(DegOfFreeDom);
                // valueChi = 0.17;
                if (t > valueChi) {
                    K2.ChiSquare[i][j] = 1;
                } else {
                    arcToRemove++;

                }
            }
        }
        System.err.println("******�����˱ߣ�" + arcToRemove + "��...");
        // BNGraph gstand= BNGraph.GetGraphStandInsurance();
        BNGraph gstand = BNGraph.GetGraphStandAlarm();
        // System.err.print(gstand);
        int[][] arcarr = gstand.GetArcArray();
        for (int i = 0; i < K2.VEXNUM; i++) {
            for (int j = 0; j < K2.VEXNUM; j++) {
                if (K2.ChiSquare[i][j] == 0 && arcarr[i][j] == 1) {
                    int tempn = (K2.NodeInfo[i].size() - 1)
                            * (K2.NodeInfo[j].size() - 1);
                    System.err.println("����ɾ���˱� i=" + i + " j=" + j + "����Ϣ��" + 2
                                    * data.length * K2.Inf[i][j]
                                    + "���ɶȣ�" + tempn + "����ֵ:" + K2.getChiSquare(tempn)
                            // K2.Inf[i][j]
                    );
                }
            }
        }

    }

    public static void CITestByValue(double a) {
        System.out.println("����X�����飬by value");
        K2.ChiSquare = new int[K2.VEXNUM][K2.VEXNUM];
        int arcToRemove = 0;
        for (int i = 0; i < K2.VEXNUM; i++) {
            for (int j = 0; j < K2.VEXNUM; j++) {
                if (i == j) {
                    continue;
                }
                double t = 2 * K2.INSTANCE.Records.length * K2.Inf[i][j];
                if (t > a) {
                    K2.ChiSquare[i][j] = 1;
                } else {
                    arcToRemove++;

                }

            }
        }

        System.err.println("******�����˱ߣ�" + arcToRemove + "��...");
        // BNGraph gstand= BNGraph.GetGraphStandInsurance();
        BNGraph gstand = BNGraph.GetGraphStandAlarm();
        // System.err.print(gstand);
        int[][] arcarr = gstand.GetArcArray();
        for (int i = 0; i < K2.VEXNUM; i++) {
            for (int j = 0; j < K2.VEXNUM; j++) {
                if (K2.ChiSquare[i][j] == 0 && arcarr[i][j] == 1) {
                    int tempn = (K2.NodeInfo[i].size() - 1)
                            * (K2.NodeInfo[j].size() - 1);
                    System.err.println("����ɾ���˱� i=" + i + " j=" + j + "����Ϣ��" + 2
                                    * K2.INSTANCE.Records.length * K2.Inf[i][j]
                                    + "���ɶȣ�" + tempn + "����ֵ:" + K2.getChiSquare(tempn)
                                    + "base:" + a
                            // K2.Inf[i][j]
                    );
                }
            }
        }

    }

    /**
     * ȡ�����Ļ���Ϣֵ
     *
     * @return double
     */

    public static double getMaxMI() {
        double infMax = 0;
        double[][] inf = K2.Inf;
        for (int i = 0; i < inf.length; i++) {
            for (int j = 0; j < inf.length; j++) {
                // System.out.print(inf[i][j] + " ");
                if (inf[i][j] > infMax) {
                    infMax = inf[i][j];
                }
            }
            // System.out.print("\r\n ");
        }
        // System.out.print("\r\n�����Ϣ��" + infMax);
        return infMax;

    }

    public static double getMinMI() {
        double infMin = Double.POSITIVE_INFINITY;
        double[][] inf = K2.Inf;
        for (int i = 0; i < inf.length; i++) {
            for (int j = 0; j < inf.length; j++) {
                if ((inf[i][j] < infMin) && inf[i][j] != 0) {
                    infMin = inf[i][j];
                }
            }
        }
        return infMin;

    }

    public static double calcInd(int x, int y, String[][] data) {
        double result = 0.0;
        int[] query = {x, y};
        int[] queryResult = K2.getCountBrutal(data, query);
        double[][] arrayProb = constructProbArray(x, y, queryResult, data);
        double[] px = constructProbX(arrayProb);// ����
        double[] py = constructProbY(arrayProb);// ����

        for (int i = 0; i < arrayProb.length; i++) {
            for (int j = 0; j < arrayProb[0].length; j++) {
                if (arrayProb[i][j] != 0.0) {
                    double temp = Math.log10(arrayProb[i][j] / px[j] / py[i]);
                    temp *= arrayProb[i][j];
                    result += temp;
                }
            }
        }
        return result;
    }

    /**
     * ������ʾ���
     *
     * @param x      int
     * @param y      int
     * @param result int[]
     * @return double[][]
     */
    private static double[][] constructProbArray(int x, int y,
                                                 int[] queryResult, String[][] data) {
        int count = 0;
        int jIndex = K2.NodeInfo[x].size();
        int iIndex = K2.NodeInfo[y].size();
        double num = data.length;
        double[][] arrayProb = new double[iIndex][jIndex];
        for (int j = 0; j < jIndex; j++) {
            for (int i = 0; i < iIndex; i++) {
                arrayProb[i][j] = queryResult[count++] / num;
            }
        }
        return arrayProb;
    }

    private static double[] constructProbX(double[][] arrayProb) {
        double[] px = new double[arrayProb[0].length];
        for (int j = 0; j < arrayProb[0].length; j++) {
            for (int i = 0; i < arrayProb.length; i++) {
                px[j] += arrayProb[i][j];
            }
        }
        return px;
    }

    private static double[] constructProbY(double[][] arrayProb) {
        double[] py = new double[arrayProb.length];
        for (int i = 0; i < arrayProb.length; i++) {
            for (int j = 0; j < arrayProb[0].length; j++) {
                py[i] += arrayProb[i][j];
            }
        }
        return py;
    }

    /**
     * ע��
     *
     * @param ori double
     * @return double
     */
    // public static double getMIRadio(int i, int j)
    // {
    // double mother = calcSquarSum();
    // System.out.println("��ĸ"+mother+"���ӣ�"+Inf[i][j]);
    // double sum = Inf[i][j]/mother;
    // return sum;
    // }
    public static double getRefect(double ori) {
        return (ori - K2.minMI) / (K2.maxMI - K2.minMI);
    }


    public static BNGraph[] b = new BNGraph[2];
    public static double[][] MDLArcScore;

    private double CalcMDLPart1(int index, ArrayList parent) {
        double d = 0;
        d = (K2.log2(this.Records.length) * 0.9) / 2;
        // d = 5.85;
        // d = Math.ceil(d);
        int vi = NodeInfo[index].size();
        double part1 = parent.size() * K2.log2(K2.VEXNUM);
        // double part1 = parent.size() * K2.log2( this.Records.length );
        // if(parent.size() > 0)
        // {
        // part1 = Math.pow(2,parent.size()) * K2.log2( K2.VEXNUM );
        // }
        double part2 = 0;
        Iterator it = parent.iterator();
        if (parent.size() > 0) {
            part2 = 1.0;
            while (it.hasNext()) {
                int ParentNode = (Integer) it.next();
                int vj = NodeInfo[ParentNode].size();
                part2 *= (vj);
            }
        }

        //return d * vi * part2;
        return part1 + d * (vi - 1) * part2;
    }

    private double CalcMDLPart2(int index, ArrayList<Integer> parent) {
        // ȡ�ó�ʼ����
        int qi = 1;
        // int ri = NodeInfo[index].size();
        double result2 = 0;

        // ȡ�ò�ѯ����
        int[] indexArray = new int[parent.size() + 1];
        for (int i = 0; i < parent.size(); i++) {
            indexArray[i + 1] = parent.get(i);
        }
        Arrays.sort(indexArray);
        indexArray[0] = index;
        // ȡ�ò�ѯ���
        int[] countResult = K2.getCountBrutal(this.Records, indexArray);

        // for(int i = 0; i < countResult.length; i++)
        // System.out.print(countResult[i]+" ");
        // System.out.println();

        for (int count = 0; count < parent.size(); count++) {
            qi = qi * NodeInfo[parent.get(count)].size();
        }
        double[] NijkArray = new double[qi];
        // ���Nij
        for (int i = 0; i < NijkArray.length; i++) {
            int step = 0;
            for (int j = 0; j < NodeInfo[index].size(); j++) {
                NijkArray[i] += countResult[i + step];
                step += qi;
            }
        }
        double[] NijArray = new double[NodeInfo[index].size() * qi];
        int pos1 = 0;
        int pos2 = 0;
        for (int i = 0; i < NodeInfo[index].size(); i++) {
            System.arraycopy(NijkArray, pos1, NijArray, pos2, NijkArray.length);
            pos2 += qi;
        }
        // System.out.println(countResult.length);
        for (int i = 0; i < countResult.length; i++) {
            if (countResult[i] != 0) {
                double para = NijArray[i] / countResult[i];
                // System.out.println(para);
                double TempLog = K2.log2(para);
                double TempResult = countResult[i] * TempLog;
                // System.out.println(TempResult);
                result2 += TempResult;
            }
            // System.out.println(result2);
        }
        return result2;
    }

    /**
     * ����MDL���֣�Ӧ�������ѯ��
     *
     * @param index  int
     * @param parent ArrayList
     * @return double
     */
    public double calcMDLUseArray(int index, ArrayList<Integer> parent) {
        double part1 = this.CalcMDLPart1(index, parent);
        //double part2 = this.CalcMDLPart2(index, parent);
        //double result = -(part2 + part1);
        double result = -(part1);
        // System.out.println(" " +part1+" , " + part2 + " = " + result);
        // System.out.println( part2 );
        return result;
    }

    // PrintWriter pw = CommonTools.getPrintWriter("c:\\cache","cache.log");

    public double calcMDLuseHMCache(int index, ArrayList<Integer> parent) {
        K2.count++;
        double result = 0.0;
        int[] indexArray = new int[parent.size() + 1];
        for (int i = 0; i < parent.size(); i++) {
            indexArray[i + 1] = parent.get(i);
        }
        Arrays.sort(indexArray);
        indexArray[0] = index;
        String indexString = this.convertToString(indexArray);
        if (this.cacheResult.containsKey(indexString)) {
            result = this.cacheResult.get(indexString);
            K2.cacheCount++;
        } else {
            result = this.calcMDLuseHM(index, parent);
            this.cacheResult.put(indexString, result);
            K2.actualCalcCount++;
        }
        return result;

    }

    public double calcMDLUseArrayCache(int index, ArrayList<Integer> parent) {

        K2.count++;
        double result = 0.0;
        int[] indexArray = new int[parent.size() + 1];
        for (int i = 0; i < parent.size(); i++) {
            indexArray[i + 1] = parent.get(i);
        }
        Arrays.sort(indexArray);
        indexArray[0] = index;
        String indexString = this.convertToString(indexArray);
        if (this.cacheResult.containsKey(indexString)) {
            result = this.cacheResult.get(indexString);
            // pw.println("����"+index+","+parent+","+result+","+indexString);
            K2.cacheCount++;
        } else {
            result = this.calcMDLUseArray(index, parent);
            this.cacheResult.put(indexString, result);
            // pw.println("����"+index+","+parent+","+result+","+indexString);

            K2.actualCalcCount++;
        }
        // pw.flush();
        return result;

    }

    /**
     * ����mdlֵ����HM calcK2BrutalCache calcMDLuseHM
     *
     * @param index  int
     * @param parent ArrayList
     * @return double
     */
    public double calcMDLuseHM(int index, ArrayList<Integer> parent) {
        double result = 0.0;
        double part1 = 0;// ��һ���ֽ��
        double d = 0;

        d = (K2.log2(this.Records.length) * 0.9) / 2;

        if (parent.size() > 0) {
            part1 = 1;
            for (int i = 0; i < parent.size(); i++) {
                int node = parent.get(i);
                part1 *= NodeInfo[node].size();
            }
        }
        // part1 *= d * (NodeInfo[index].size()-1);
        // part1 += parent.size() * K2.log2(K2.VEXNUM);
        part1 *= d * NodeInfo[index].size();

        // ������ѯ����
        int[] parentArray = new int[parent.size()];
        int[] allArray = new int[parent.size() + 1];

        for (int i = 0; i < parent.size(); i++) {
            parentArray[i] = parent.get(i);
        }
        Arrays.sort(parentArray);
        System.arraycopy(parentArray, 0, allArray, 1, parentArray.length);
        allArray[0] = index;
        // ȡ�ò�ѯ���
        HashMap parentResult = K2.getCount(this.Records, parentArray);
        HashMap allResult = K2.getCount(this.Records, allArray);

        // System.out.println(parentResult);
        // System.out.println(allResult);

        Set allKey = allResult.keySet();
        // System.out.println(allKey);
        Iterator it = allKey.iterator();
        double part2 = 0.0;
        while (it.hasNext()) {
            String key = (String) it.next();
            String pareKey = this.getPareKey(key);
            double allValue = (Integer) allResult.get(key);
            double paraValue = (Integer) parentResult.get(pareKey);
            double temp1 = paraValue / allValue;
            double temp = allValue * K2.log2(temp1);
            // System.out.println("temp"+temp);
            part2 += temp;
        }
        result = -(part1 + part2);
        //	System.out.println("HM:part1="+part1+",part2="+part2);
        return result;
    }

    /**
     * �������Ĳ�ѯ����У�ȡ�õ�ǰ��ѯ����ĸ�ĸ�ڵ��key��
     */
    public String getPareKey(String key) {
        int pos = key.indexOf(";");
        String parentKey = key.substring(pos + 1, key.length());
        return parentKey;
    }

    public boolean isDataMiss(String[] data, ArrayList<Integer> index) {
        boolean tag = false;
        for (int i = 0; i < index.size(); i++) {
            if (data[i].equals("?"))
                tag = true;
        }
        return tag;
    }

    @Override
    public double calcGraphScore(BNGraph g) {
        double score = 0.0;
        double size = g.getVexNum();
        for (int i = 0; i < size; i++) {
            ArrayList parent = g.GetNode(i).GetParentNodesIndex();
            double nodescore = this.calcScore(i, parent);
            score += nodescore;
        }

        return score;

    }


    public static BNGraph HillClimbing(BNGraph G_k, Score a) {
        HillClimbing hill = new HillClimbing(G_k, a);
        G_k = hill.OptimizeBN();
        //G_k = hill.OptimizeBN_CI();
        return G_k;
    }

    //���ַ�������ת��double����
    public static double[][] strtodouble(String[][] str) {
        int a, b;
        a = str.length;
        b = str[0].length;
        double result[][] = new double[a][b];
        for (int i = 0; i < a; ++i) {
            for (int j = 0; j < b; ++j) {

                result[i][j] = Double.parseDouble(str[i][j]);
            }
        }
        return result;
    }

    public double calcMDLuseHMandte(int index, ArrayList<Integer> parent) {
        AlarmReader ar = new AlarmReader("E:\\NEWS\\te5-50.txt", 5, 5);
        double[][] t = strtodouble(ar.GetDataSet()); //��ȡ������

        double result = 0.0;
        double part1 = 0;// ��һ���ֽ��
        double d = 0;


        d = (K2.log2(this.Records.length) * 0.9) / 2;

        if (parent.size() > 0) {
            part1 = 1;
            for (int i = 0; i < parent.size(); i++) {
                int node = parent.get(i);
                part1 *= NodeInfo[node].size();
            }
        }
        // part1 *= d * (NodeInfo[index].size()-1);
        // part1 += parent.size() * K2.log2(K2.VEXNUM);
        part1 *= d * NodeInfo[index].size();

        // ������ѯ����
        int[] parentArray = new int[parent.size()];
        int[] allArray = new int[parent.size() + 1];

        for (int i = 0; i < parent.size(); i++) {
            parentArray[i] = parent.get(i);
        }
        Arrays.sort(parentArray);
        System.arraycopy(parentArray, 0, allArray, 1, parentArray.length);
        allArray[0] = index;
        // ȡ�ò�ѯ���
        HashMap parentResult = K2.getCount(this.Records, parentArray);
        HashMap allResult = K2.getCount(this.Records, allArray);

        // System.out.println(parentResult);
        // System.out.println(allResult);

        Set allKey = allResult.keySet();
        // System.out.println(allKey);
        Iterator it = allKey.iterator();
        double part2 = 0.0;
        while (it.hasNext()) {
            String key = (String) it.next();
            String pareKey = this.getPareKey(key);
            double allValue = (Integer) allResult.get(key);
            double paraValue = (Integer) parentResult.get(pareKey);
            double temp1 = paraValue / allValue;
            double temp = allValue * K2.log2(temp1);
            // System.out.println("temp"+temp);
            part2 += temp;
        }

        double part3 = 0.0;
        if (parent.size() > 0) {
            for (int i = 0; i < parent.size(); i++) {
                int node = parent.get(i);
                part3 += t[i][node];
            }
        }

        result = -(part1 + part2 + part3);
        //	result = -(part2 + part3);
        System.out.println("HM:part1=" + part1 + ",part2=" + part2 + ",part3=" + part3);
        return result;
    }

    /**
     * CTE
     */
    public double calDoge(int index, ArrayList<Integer> parent) {
        double[][] t = strtodouble(getRecord());
        return -calPart1(index, parent, t) + calPart2(index, parent, t, t.length - 1) - calPart3(index, parent, t);
    
    }

    public double calPart1(int index, ArrayList<Integer> parent, double[][] t) {
        double part1 = 0;
        for (int n : parent) {
            part1 += H(T(t, index), T(t, n)) - H(T(t, n));
        }
      //  System.err.println("Part1: " + part1);
        return part1;
    }

    public double calPart2(int index, ArrayList<Integer> parent, double[][] t, int m) {
        double part2 = 0;
        for (int n : parent) {
            part2 += H(chooseLastM(T(t, index), m), choosePrevM(T(t, index), m))
                    + H(choosePrevM(T(t, index), m), choosePrevM(T(t, n), m))
                    + H(chooseLastM(T(t, index), m), choosePrevM(T(t, index), m), choosePrevM(T(t, n), m))
                    + H(choosePrevM(T(t, index), m));
        }
      //   System.err.println("Part2: " + part2);
        return part2;
    }

    public double calPart3(int index, ArrayList<Integer> parent, double[][] t) {
        Set<Double> set = new HashSet<>();
        for (int i = 0; i < t.length; i++) {
            set.add(t[i][index]);
        }
        for (int n : parent) {
            for (int i = 0; i < t.length; i++) {
                set.add(t[i][n]);
            }
        }
        int pi = set.size();
        int pj = t.length;
        
       // System.err.println("set: " + pi+ ",length: "+pj);
      //  return 0.5 * pi*  Math.log(t.length);
        return 0;
    }

 

    
    /**
     * ��ά�����е�ĳһ��ת��Ϊһά����
     * @param t ��ά����
     * @param n ĳһ��
     * @return
     */
    private static double[] T(double[][] t, int n) {
        double[] res = new double[t.length];
        for (int i = 0; i < res.length; i++) {
            res[i] = t[i][n];
        }
        return res;
    }

    /**
     * ѡ������ǰm��
     *
     * @param t ����
     * @param m ǰm��
     */
    private static double[] choosePrevM(double[] t, int m) {
        double[] res = new double[m];
        for (int i = 0; i < m; i++) {
            res[i] = t[i];
        }
        return res;
    }

    /**
     * ѡ�������m��
     *
     * @param t ����
     * @param m ��m��
     */
    private static double[] chooseLastM(double[] t, int m) {
        double[] res = new double[m];
        int idx = 0;
        for (int i = t.length - m; i < t.length; i++) {
            res[idx] = t[i];
        }
        return res;
    }

    /**
     * ��H��x��
     *
     * @param n x
     */
    private static double H(double[] n) {
        double sigma = 0;
        int N = n.length;
        for (int i = 0; i < N - 1; i++) {
            sigma += Math.log(Math.abs(n[i + 1] - n[i]));
        }
        return 1.0 / (N - 1) * sigma - Gamma.digamma(1) + Gamma.digamma(N);
    }

    /**
     * ��H��x,y��
     *
     * @param n1 x
     * @param n2 y
     */
    private static double H(double[] n1, double[] n2) {
        double sigma = 0;
        int N = n1.length;
        for (int i = 0; i < N - 1; i++) {
            sigma += Math.log(Math.max(Math.abs(n1[i + 1] - n1[i]), Math.abs(n2[i + 1] - n2[i])));
        }
        return 2.0 / (N - 1) * sigma - Gamma.digamma(1) + Gamma.digamma(N);
    }

    /**
     * ��H��x,y,z��
     *
     * @param n1 x
     * @param n2 y
     * @param n3 z
     */
    private static double H(double[] n1, double[] n2, double[] n3) {
        double sigma = 0;
        int N = n1.length;
        for (int i = 0; i < N - 1; i++) {
            sigma += Math.log(Math.max(Math.max(Math.abs(n1[i + 1] - n1[i]), Math.abs(n2[i + 1] - n2[i])), Math.abs(n3[i + 1] - n3[i])));
        }
        return 3.0 / (N - 1) * sigma - Gamma.digamma(1) + Gamma.digamma(N);
    }

    /**
     * �����������֣�cte ��Ϊ�ӿ��ð�
     *
     * @param index  int
     * @param parent ArrayList
     * @return double
     */
    @Override
    public double calcScore(int index, ArrayList<Integer> parent) {

    	// return this.calcK2Cache(index, parent);   //K2����
   	 //return this.calcMDLuseHMCache(index, parent); //MDL����	
    	//	 return this.calcMDLUseArray(index, parent); //MDL����
    	//	 return this.calcMDLuseHMandte(index, parent); //MDL����
        return calDoge(index, parent);
    }

    
    /**
     * ������
     *
     * @param args String[]
     */
    public static void main(String[] args) {
        BNGraph g1 = BNGraph.GetGraphStandAlarm(); //��׼ͼ
        Score k1 = new K2("F:\\data-t\\sim1.txt", 10000, 5);
        double score = k1.calcGraphScore(g1);
        System.out.println("��׼ͼMDL����Ϊ��" + score);
        
        BNGraph g2 = BNGraph.GetGraph2(); //��һ��
        Score k2 = new K2("F:\\data-t\\sim1.txt", 10000, 5);
        double score2 = k2.calcGraphScore(g2);
        System.out.println("��һͼMDL����Ϊ��" + score2);
        
        BNGraph g3 = BNGraph.GetGraph3(); //��һ��
        Score k3 = new K2("F:\\data-t\\sim1.txt", 10000, 5);
        double score3 = k3.calcGraphScore(g3);
        System.out.println("��һͼMDL����Ϊ��" + score3);
        
        BNGraph g5 = BNGraph.GetGraph4(); //��3��
        Score k5 = new K2("F:\\data-t\\sim1.txt", 10000, 5);
        double score5 = k5.calcGraphScore(g5);
        System.out.println("����ͼMDL����Ϊ��" + score5);
        
        BNGraph g6 = BNGraph.GetGraph5(); //��һ��
        Score k6 = new K2("F:\\data-t\\sim1.txt", 10000, 5);
        double score6 = k6.calcGraphScore(g6);
        System.out.println("��һͼMDL����Ϊ��" + score6);
        
        BNGraph g7 = BNGraph.GetGraph6(); //��
        Score k7 = new K2("F:\\data-t\\sim1.txt", 10000, 5);
        double score7 = k7.calcGraphScore(g7);
        System.out.println("��ͼMDL����Ϊ��" + score7);
        
        BNGraph g8 = BNGraph.GetGraph1(); //��
        Score k8 = new K2("F:\\data-t\\sim1.txt", 10000, 5);
        double score8 = k8.calcGraphScore(g8);
        System.out.println("������MDL����Ϊ��" + score8);
    }
//        try {
//
//            BNGraph g = BNGraph.GetGraphStandAlarm(); //��׼ͼ
//            BNGraph g3 = BNGraph.GetGraph3(); //��ͼ
//            BNGraph g6 = BNGraph.GetGraph6(); //��ͼ
//            BNGraph g2 = BNGraph.GetGraph2();
//            BNGraph g1 = BNGraph.GetGraph1();
//            BNGraph g4 = BNGraph.GetGraph4();
//            BNGraph g5 = BNGraph.GetGraph5();
//
//
//            Score k2 = new K2("E:\\NEWS\\sim5-50.txt", 10000, 5);
//	/*		BNGraph temp = new BNGraph(5);
//			BNGraph bestg=HillClimbing(g3,k2);
//			bestg=HillClimbing(bestg,k2);
//			for (int i = 0; i < 100; i++) {
//                temp=HillClimbing(bestg,k2);
//                double s1 = k2.calcGraphScore(temp);
//                double s2 = k2.calcGraphScore(bestg);
//				if(s1>s2)
//					bestg=temp;
//			}
//
//
//		double score = k2.calcGraphScore(g);
//	    System.out.println("��׼ͼMDL����Ϊ��"+score);
//
//	    double score1 = k2.calcGraphScore(g1);
//	    System.out.println("����ͼ1MDLBIC����Ϊ��"+score1);
//
//	    double score2 = k2.calcGraphScore(g2);
//	    System.out.println("����ͼ2MDLBIC����Ϊ��"+score2);
//
//	    double score3 = k2.calcGraphScore(g3);
//	    System.out.println("����ͼ3MDLBIC����Ϊ��"+score3);
//
//	    double score4 = k2.calcGraphScore(g4);
//	    System.out.println("����ͼ3MDLBIC����Ϊ��"+score4);
//
//	    double score5 = k2.calcGraphScore(g5);
//	    System.out.println("����ͼ3MDLBIC����Ϊ��"+score5);
//
//
//	    System.out.println(g.tograph());
//	    System.out.println(g1.tograph());
//	    System.out.println(g2.tograph());
//	    System.out.println(g3.tograph());
// */
//            double score3 = k2.calcGraphScore(g3);
//            System.out.println("����ͼ3MDLBIC����Ϊ��" + score3);
//
//            double score4 = k2.calcGraphScore(g4);
//            System.out.println("����ͼ4MDLBIC����Ϊ��" + score4);
//
//            double score6 = k2.calcGraphScore(g6);
//            System.out.println("����ͼ6MDLBIC����Ϊ��" + score6);
//
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//
//    }
}
