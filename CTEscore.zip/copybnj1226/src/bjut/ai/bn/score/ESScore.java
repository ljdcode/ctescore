package bjut.ai.bn.score;

public class ESScore {

}
