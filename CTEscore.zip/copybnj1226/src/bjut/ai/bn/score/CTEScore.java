package bjut.ai.bn.score;

/**
 * <p>Title: K2</p>
 *
 * <p>Description: ����K2����</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.HillClimbing;
import bjut.ai.bn.learning.acob.AlarmReader;

import org.apache.commons.math3.special.Gamma;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class CTEScore extends Score {
    // ����Ϣ
    public static double maxMI;
    public static double minMI;
    public static double[][] Inf;
    public static int[][] ChiSquare;
    // record ʵ������ indexs Ҫ��ѯ�Ľڵ����飬���ز�ѯ���ΪHashMap
    public static PrintWriter out;


    public static int VEXNUM = 5;//��Ҫ��
    //  public static int VEXNUM = 12;//��Ҫ��

    
    public static CTEScore INSTANCE = null;

    // �������
    public static int cacheCount = 0;// ����ĸ���
    public static int count = 0;// ���ü������
    public static int actualCalcCount = 0;
    public static TreeSet[] NodeInfo;

    public static enum TYPE {
        ORI, CI, CInew, HF, OP, AIO, SA, PC
    }

    ;

    private String[][] Records;
    private HashMap<String, Double> hm; // �м����
    public HashMap<String, Double> cacheResult;
    private int ri;

  

    public CTEScore(String fileName, int size, int nodeNums) {
        AlarmReader ar = new AlarmReader(fileName, size, nodeNums);
        this.Records = ar.GetDataSet();
        K2.NodeInfo = ar.getColumnValue();
        this.cacheResult = new HashMap<String, Double>();
    }


    public String[][] getRecord() {
        return this.Records;
    }

    @Override
    public void clearCache() {
        System.out.println("�������");
        K2.count = 0;
        K2.cacheCount = 0;
        K2.actualCalcCount = 0;
        this.cacheResult = new HashMap<String, Double>();
    }



  

    /**
     * ת��int[]Ϊ�����ַ���
     *
     * @param array int[]
     * @return String
     */
    private String convertToString(int[] array) {
        StringBuilder sb = new StringBuilder();
        for (int k : array) {
            sb.append(k);
            sb.append(",");
        }
        return sb.toString();
    }

    public static PrintWriter getPrinWriter(String filename) throws IOException {
        File dir = new File("c:" + File.separator + "BayesianLog_Alarm_mdl");
        dir.mkdir();
        File file = new File(dir, filename + ".csv");
        return new PrintWriter(new FileWriter(file, false));
    }

    private String convertToString(ArrayList<Integer> al) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0, size = al.size(); i < size; i++) {
            sb.append(al.get(i));
            sb.append(",");
        }
        return sb.toString();
    }

   


    /**
     * ����log(n!)
     *
     * @param n int
     * @return double
     */
    private static double calcLog(int n) {
        double result = 0;
        for (int i = 1; i <= n; i++) {
            result = result + java.lang.Math.log10(i);
        }
        return result;
    }

    /**
     * log2
     *
     * @param value double
     * @return double
     */
    public static double log2(double value) {
        return Math.log(value) / Math.log(2);

    }

    /**
     * �ڲ�ʹ��
     *
     * @param index     int
     * @param parentIJK int[]
     * @return double
     */
 
    private static HashMap getCount(String[][] record, int[] indexs) {
        HashMap hm = new HashMap();
        StringBuilder sb;
        Object tempcount;
        for (int i = 0; i < record.length; i++) {
            sb = new StringBuilder();
            for (int j = 0; j < indexs.length; j++) {

                sb.append(record[i][indexs[j]]);
                sb.append(";");
            }
            String temp = sb.toString();
            int count = 0;
            if ((tempcount = hm.get(temp)) != null) {
                count = (Integer) tempcount;
            }
            hm.put(temp, ++count);
        }
        // System.out.println("��ѯ�ڵ�");
        // for (int k : indexs)
        // System.out.print(k + ",");
        // System.out.println("");
        // System.out.println(hm);
        return hm;
    }



    /**
     * @param array int[]
     * @return int
     */
    private static int calcStringToIndex(int[] array, int[] indexs) {
        int index = 0;
        for (int i = 0; i < array.length; i++) {
            int temp = 1;
            for (int j = i + 1; j < array.length; j++) {
                temp = temp * NodeInfo[indexs[j]].size();
            }
            index = index + array[i] * temp;
        }

        return index;
    }

    /**
     * for test only
     */




    // �����Բ��Բ���

   

    /**
     * @param n int
     * @return double
     */
    private static double getChiSquare(int n) {
        // n ���ɶ� ����鿨������
        // �� = 0.005

        double[] chi = {7.879, 10.597, 12.838, 14.860, 16.750, 18.548, 20.278,
                21.955, 23.589, 25.188, 26.757, 28.299, 29.819, 31.319, 32.801,
                34.267, 35.718, 37.156, 38.582};


        return chi[n - 1];

    }

   

    private static double[] constructProbX(double[][] arrayProb) {
        double[] px = new double[arrayProb[0].length];
        for (int j = 0; j < arrayProb[0].length; j++) {
            for (int i = 0; i < arrayProb.length; i++) {
                px[j] += arrayProb[i][j];
            }
        }
        return px;
    }

    private static double[] constructProbY(double[][] arrayProb) {
        double[] py = new double[arrayProb.length];
        for (int i = 0; i < arrayProb.length; i++) {
            for (int j = 0; j < arrayProb[0].length; j++) {
                py[i] += arrayProb[i][j];
            }
        }
        return py;
    }

    /**
     * ע��
     *
     * @param ori double
     * @return double
     */
    // public static double getMIRadio(int i, int j)
    // {
    // double mother = calcSquarSum();
    // System.out.println("��ĸ"+mother+"���ӣ�"+Inf[i][j]);
    // double sum = Inf[i][j]/mother;
    // return sum;
    // }
    public static double getRefect(double ori) {
        return (ori - K2.minMI) / (K2.maxMI - K2.minMI);
    }


    public static BNGraph[] b = new BNGraph[2];
    public static double[][] MDLArcScore;

   


    @Override
    public double calcGraphScore(BNGraph g) {
        double score = 0.0;
        double size = g.getVexNum();
        for (int i = 0; i < size; i++) {
            ArrayList parent = g.GetNode(i).GetParentNodesIndex();
            double nodescore = this.calcScore(i, parent);
            score += nodescore;
        }

        return score;

    }


    public static BNGraph HillClimbing(BNGraph G_k, Score a) {
        HillClimbing hill = new HillClimbing(G_k, a);
        G_k = hill.OptimizeBN();
        //G_k = hill.OptimizeBN_CI();
        return G_k;
    }

    //���ַ�������ת��double����
    public static double[][] strtodouble(String[][] str) {
        int a, b;
        a = str.length;
        b = str[0].length;
        double result[][] = new double[a][b];
        for (int i = 0; i < a; ++i) {
            for (int j = 0; j < b; ++j) {

                result[i][j] = Double.parseDouble(str[i][j]);
            }
        }
        return result;
    }

  

    /**
     * �����������֣���Ϊ�ӿ��ð�
     *
     * @param index  int
     * @param parent ArrayList
     * @return double
     */
    @Override
    public double calcScore(int index, ArrayList<Integer> parent) {

        //	return this.calcMDLuseHM(index, parent);    //BIC����
        return calCTE(index, parent);
    }

    /**
     *����cte
     */
    public double calCTE(int index, ArrayList<Integer> parent) {
        double[][] t = strtodouble(getRecord());
        return -calPart1(index, parent, t) + calPart2(index, parent, t, t.length - 1) - calPart3(index, parent, t);
    }

    public double calPart1(int index, ArrayList<Integer> parent, double[][] t) {
        double part1 = 0;
        for (int n : parent) {
            part1 += H(T(t, index), T(t, n)) - H(T(t, n));
        }
        return part1;
    }

    public double calPart2(int index, ArrayList<Integer> parent, double[][] t, int m) {
        double part2 = 0;
        for (int n : parent) {
            part2 += H(chooseLastM(T(t, index), m), choosePrevM(T(t, index), m))
                    + H(choosePrevM(T(t, index), m), choosePrevM(T(t, n), m))
                    + H(chooseLastM(T(t, index), m), choosePrevM(T(t, index), m), choosePrevM(T(t, n), m))
                    + H(choosePrevM(T(t, index), m));
        }
        return part2;
    }

    public double calPart3(int index, ArrayList<Integer> parent, double[][] t) {
        Set<Double> set = new HashSet<>();
        for (int i = 0; i < t.length; i++) {
            set.add(t[i][index]);
        }
        for (int n : parent) {
            for (int i = 0; i < t.length; i++) {
                set.add(t[i][n]);
            }
        }
        int pi = set.size();
        return 0.5 * pi * Math.log(t.length);
    }

    /**
     * ��ά�����е�ĳһ��ת��Ϊһά����
     * @param t ��ά����
     * @param n ĳһ��
     * @return
     */
    private static double[] T(double[][] t, int n) {
        double[] res = new double[t.length];
        for (int i = 0; i < res.length; i++) {
            res[i] = t[i][n];
        }
        return res;
    }

    /**
     * ѡ������ǰm��
     *
     * @param t ����
     * @param m ǰm��
     */
    private static double[] choosePrevM(double[] t, int m) {
        double[] res = new double[m];
        for (int i = 0; i < m; i++) {
            res[i] = t[i];
        }
        return res;
    }

    /**
     * ѡ�������m��
     *
     * @param t ����
     * @param m ��m��
     */
    private static double[] chooseLastM(double[] t, int m) {
        double[] res = new double[m];
        int idx = 0;
        for (int i = t.length - m; i < t.length; i++) {
            res[idx] = t[i];
        }
        return res;
    }

    /**
     * ��H��x��
     *
     * @param n x
     */
    private static double H(double[] n) {
        double sigma = 0;
        int N = n.length;
        for (int i = 0; i < N - 1; i++) {
            sigma += Math.log(Math.abs(n[i + 1] - n[i]));
        }
        return 1.0 / (N - 1) * sigma - Gamma.digamma(1) + Gamma.digamma(N);
    }

    /**
     * ��H��x,y��
     *
     * @param n1 x
     * @param n2 y
     */
    private static double H(double[] n1, double[] n2) {
        double sigma = 0;
        int N = n1.length;
        for (int i = 0; i < N - 1; i++) {
            sigma += Math.log(Math.max(Math.abs(n1[i + 1] - n1[i]), Math.abs(n2[i + 1] - n2[i])));
        }
        return 1.0 / (N - 1) * sigma - Gamma.digamma(1) + Gamma.digamma(N);
    }

    /**
     * ��H��x,y,z��
     *
     * @param n1 x
     * @param n2 y
     * @param n3 z
     */
    private static double H(double[] n1, double[] n2, double[] n3) {
        double sigma = 0;
        int N = n1.length;
        for (int i = 0; i < N - 1; i++) {
            sigma += Math.log(Math.max(Math.max(Math.abs(n1[i + 1] - n1[i]), Math.abs(n2[i + 1] - n2[i])), Math.abs(n3[i + 1] - n3[i])));
        }
        return 1.0 / (N - 1) * sigma - Gamma.digamma(1) + Gamma.digamma(N);
    }

    /**
     * ������
     *
     * @param args String[]
     */
    public static void main(String[] args) {
        BNGraph g = BNGraph.GetGraphStandAlarm(); //��׼ͼ
        Score CTE = new CTEScore("F:\\data-t\\sim1.txt", 10000, 5);
        double score = CTE.calcGraphScore(g);
        //double score = k2.calcScore(g);
        System.out.println("��׼ͼMDL����Ϊ��" + score);
    }

}
