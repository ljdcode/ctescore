package bjut.ai.bn.score;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import bjut.ai.bn.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.sem.EM;
import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.BBNPDF;

public class EMDLScore extends Score{

	private BBNGraph g = null;
	private EM em = null;
	private String[][] missdata;
	Hashtable AllMijk = null;
	Hashtable AllTheta = null;
	private int vexnum = 0;
	
	public EMDLScore(BBNGraph g, String[][] missdata)
	{
		this.vexnum = g.getNodeNames().size();
		em = new EM();
		this.g = g;
		this.missdata = missdata;
		this.init();
	}
	private void init()
	{
		 AllMijk = em.getAllMijk(g, missdata);
		 AllTheta = em.calcAllThetaijk(g, AllMijk);
	}
	
	/**
	 * ����һ���ڵ�index������
	 */
	@Override
	public double calcScore(int index, ArrayList<Integer> parent) {
		double score = 0.0;
		double part1 = 1.0;
		double part2 = 0.0;
		String CurNodeName = AlarmReader.index2nodeName.get(index+1);
		Hashtable theta = (Hashtable)AllTheta.get(CurNodeName);
		Hashtable Mijk = (Hashtable)AllMijk.get(CurNodeName);
		
		Set keys = Mijk.keySet();
		Iterator iter = keys.iterator();
		while(iter.hasNext())
		{
			Hashtable curKey = (Hashtable)iter.next();
			BBNPDF thetavalue = (BBNPDF)theta.get(curKey);
			double mijkvalue = (Double)Mijk.get(curKey);
//			System.out.println(thetavalue + " " + mijkvalue);
//			System.out.println(part1);
			part1 += (part1 * mijkvalue* Math.log10(thetavalue.getValue()));
		}
		part2 = 0.5*Math.log10(vexnum)*theta.size();
		score = part1 - part2;
		return score;
	}
	
	
	
	
	
	
	@Override
	public void clearCache()
	{
	}
	@Override
	public double calcGraphScore(BNGraph g)
	{
		return Double.NaN;
	}
	
	

	
	
}
