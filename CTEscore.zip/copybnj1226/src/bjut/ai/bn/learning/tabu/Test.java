package bjut.ai.bn.learning.tabu;

import java.io.PrintWriter;

import bjut.ai.bn.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;

public class Test {
	
	public static void testTabuList()
	{
		 TabuList tl = new TabuList(10);
		 int from = 0;
		 int to = 0;
		 for(int i = 0; i < 11; i++)
		 {
			 from++;
			 to = from+1;
			 OperRecord oper1 = new OperRecord(2.0,from,to,TBN.tag.ADD);
			 tl.add(oper1);
		 }
		 System.out.print(tl);
	}
	public static void testTBN()
	{
		BNGraph standard = BNGraph.GetGraphStandAlarm();
		try {
			BNGraph gk2sn = new BNGraph(K2.VEXNUM);
			AlarmReader ar = new AlarmReader("data\\alarmacob.txt",3000,37);
			String[][] data = ar.GetDataSet();
			Score k2 = new K2(data);
			K2.INSTANCE = K2.getK2(data, 37);
			
			// ���ò���
			int maxiter = 1000;
			int tabulength = 121;
			
			TBN tbn = new TBN(gk2sn, maxiter, tabulength, true);
			tbn.setScoreMethod(k2);
			PrintWriter log = CommonTools.getPrintWriter("c:\\TBN", "tllLog.txt");
			gk2sn = tbn.goTBN();
			log.println(BNGraph.CompareGraph2(standard, gk2sn)+" ��õķ�����" + tbn.bestOccur);
			System.out.println(BNGraph.CompareGraph2(standard, gk2sn)+" ��õķ�����" + tbn.bestOccur);
			
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static void testTBNtabulistlength()
	{
		BNGraph standard = BNGraph.GetGraphStandAlarm();
		try {
			AlarmReader ar = new AlarmReader("data\\alarmacob.txt",3000,37);
			String[][] data = ar.GetDataSet();
			Score k2 = new K2(data);
			K2.INSTANCE = K2.getK2(data, 37);
			
			PrintWriter log = CommonTools.getPrintWriter("c:\\TBN", "tllLog.txt");
			for (int i = 130; i < 140; i += 1)
			{
				BNGraph gk2sn = new BNGraph(K2.VEXNUM);
				TBN tbn = new TBN(gk2sn, 2000, i, true);
				tbn.setScoreMethod(k2);
				gk2sn = tbn.goTBN();
				log.println("tll="+i+"  "+BNGraph.CompareGraph2(standard, gk2sn)+" ��õķ�����" + tbn.bestOccur);
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	
	public static void main(String[] args)
	{
		long start = System.currentTimeMillis();
		//Test.testTBNtabulistlength();
		 Test.testTBN();
		long end = System.currentTimeMillis();
		
		System.out.println("time:"+(end-start));
	}

}
