package bjut.ai.bn.learning.tabu;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.score.K2;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class TabuList
{
  private int length;
  public int[][] tabuList;//ij ��jָ��i
  public int[][] tabuFrequency;//��¼�����ɵĴ���
  public int[][] bestArcCount;//i->j
  
  public TabuList(int length)
  {
    tabuList = new int[K2.VEXNUM][K2.VEXNUM];
    this.tabuFrequency = new int[K2.VEXNUM][K2.VEXNUM];
    this.bestArcCount = new int[K2.VEXNUM][K2.VEXNUM];
    this.length = length;
  }

  public void setLength(int l)
  {
	  this.length = l;
  }

  /**
   * ����������������
   * @param oper OperRecord
   */
  public void add(OperRecord oper)
  {
    this.updateTabuList();
    this.updateTabuFrequency(oper);
    if(oper.tag == TBN.tag.REV)
    {
    	this.tabuList[oper.to][oper.from] = this.length;
    	this.tabuList[oper.from][oper.to] = this.length;
    }
    else
    {
        this.tabuList[oper.to][oper.from] = this.length;
    }
  }

  public void updateTabuFrequency(OperRecord oper)
  {
    this.tabuFrequency[oper.to][oper.from]++;
  }

  
  public void updateBestArcCount(BNGraph curbest)
  {
	  int[][] arcs = curbest.GetArcArray();
	  for(int i = 0; i < arcs.length; i++)
	  {
		  for(int j = 0; j < arcs[0].length; j++)
		  {
			  if(arcs[i][j] == 1)
			  {
				  this.bestArcCount[i][j]++;
			  }
		  }
	  }
  }
  /**
   * �鿴����״̬
   * @param oper OperRecord
   * @return boolean
   */
  public boolean isTabu(OperRecord oper)
  {
    boolean tag = true;
    if(this.tabuList[oper.to][oper.from] == 0)
      tag = false;
    return tag;
  }
  /**
   * ���½��ɱ�
   */
  public void updateTabuList()
  {
    for(int i = 0; i < this.tabuList.length; i++)
    {
      for(int j = 0; j < this.tabuList[0].length; j++)
      {
        if (this.tabuList[i][j] != 0)
          this.tabuList[i][j]--;
      }
    }
  }

  @Override
public String toString()
  {
    StringBuilder sb = new StringBuilder();
    sb.append("�����ɵı���[");
    for(int i = 0; i < this.tabuList.length; i++)
    {
      for(int j = 0; j < this.tabuList[0].length; j++)
      {
        if(this.tabuList[i][j] != 0)
        {
          sb.append(j+"->"+i+"("+this.tabuList[i][j]+")"+",");
        }
      }
    }
    sb.append("]");
    return sb.toString();
  }

  public static void main(String[] args)
  {
	  TabuList tl = new TabuList(2);
	  OperRecord oper1 = new OperRecord(1.0,1,2,TBN.tag.DEL);
	  OperRecord oper2 = new OperRecord(1.0,1,2,TBN.tag.ADD);
	  tl.add(oper1);

	  tl.updateTabuList();
//	  tl.updateTabuList();

	  System.out.print(tl.isTabu(oper2));

  }
}
