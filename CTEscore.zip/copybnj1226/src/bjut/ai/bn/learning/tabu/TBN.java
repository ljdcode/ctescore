package bjut.ai.bn.learning.tabu;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Queue;

import bjut.ai.bn.BNGraph;
import bjut.ai.bn.BNNode;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;
public class TBN {
	public static enum tag {
		ADD, DEL, REV
	};

	private BNGraph GlobalBest;
	private BNGraph initSolution;
	private int maxIterTimes;
	private TabuList tabulist;
	private AspirationList al;
	private PrintWriter LogOut = null;
	private int firstK = 4;
	private int punishTag = 5;
	private double punishS = -300.0;
	private Score score = null;
	
	
	public int bestOccur;
	private boolean debug;
	public static double[][] punishScore = new double[K2.VEXNUM][K2.VEXNUM];
//	public static PrintWriter log = CommonTools.getPrintWriter("c:\\TBN", "tbnlog.txt");
	
	public TBN(BNGraph initSolution, int itTimes, int tabuLength, boolean debug) {
		this.initSolution = initSolution;
		this.maxIterTimes = itTimes;
		this.GlobalBest = new BNGraph(K2.VEXNUM);
		this.GlobalBest.K2Score = Double.NEGATIVE_INFINITY;
		this.tabulist = new TabuList(tabuLength);
		this.debug = debug;
		this.firstK = tabuLength / 2;
		this.al = new AspirationList();
	}
	
	public void setTabuListLength(int l)
	{
		this.tabulist.setLength(l);
	}
	public void setScoreMethod(Score s)
	{
		this.score = s;
	}


	//
	// /**
	// * ���ɱ�Ҷ˹���磬�ñ߽��ɱ�
	// *
	// * @return BNGraph
	// * @throws IOException
	// */
	// public BNGraph genArcTabu() throws IOException {
	// this.LogOut = CommonTools.getPrintWriter("c:\\TBN", "tabuarc.txt");
	// // K2.calcInf();
	// // K2.CITest();
	// BNGraph currentSolution = (BNGraph) this.initSolution.clone();
	// // generate neighborhood solution
	// for (int i = 0; i < this.maxIterTimes; i++) {
	// boolean tag = true;
	// Queue neighS = this.genNeighSolution(currentSolution);
	// if (debug) {
	// this.LogOut.print("ȫ����������ֵ��" + this.GlobalBest.K2Score);
	// this.LogOut.println("  ��ǰ�������ֵ��" + currentSolution.K2Score);
	// this.LogOut.println(this.tabulist);
	// }
	//
	// while (tag) {
	// OperRecord oper = (OperRecord) (neighS.poll());
	// if (debug) {
	// this.LogOut.println("������ " + oper);
	// }
	// if (this.tabulist.isTabu(oper)) // ������
	// {
	// if (debug) {
	// this.LogOut.println("������");
	// }
	//
	// if (this.isAspirate(oper)) // �ƽ�
	// {
	// if (debug) {
	// this.LogOut.println("�ƽ�");
	// }
	// this.execOper(currentSolution, oper);
	// if (currentSolution.K2Score > this.GlobalBest.K2Score) {
	// if (debug) {
	// this.LogOut.println("����ȫ�����Ž�");
	// }
	//							
	// this.GlobalBest = (BNGraph) currentSolution.clone();
	// this.GlobalBest.K2Score = currentSolution.K2Score;
	// this.bestOccur = i;
	// }
	// // ���½��ɱ�
	// if (debug) {
	// this.LogOut.println("���½��ɱ�");
	// }
	// // BNNode node = currentSolution.GetNode(oper.to);
	// // this.tb.add(node);
	// this.tabulist.add(oper);
	// tag = false;
	// } else // ����������׼��
	// {
	// this.LogOut.println("�������ƽ�׼��");
	// }
	// } else // ��,���½⣬���½��ɱ�
	// {
	// this.LogOut.println("û�б�����");
	// this.execOper(currentSolution, oper);
	// if (currentSolution.K2Score > this.GlobalBest.K2Score) {
	// if (debug) {
	// this.LogOut.println("����ȫ�����Ž�");
	// }
	// this.GlobalBest = (BNGraph) currentSolution.clone();
	// this.GlobalBest.K2Score = currentSolution.K2Score;
	// this.bestOccur = i;
	// }
	// // ���½��ɱ�
	// if (debug) {
	// this.LogOut.println("���½��ɱ�");
	// }
	// // BNNode node = currentSolution.GetNode(oper.to);
	// // this.tb.add(node);
	// this.tabulist.add(oper);
	// tag = false;
	// }
	// }
	// }
	// this.LogOut.close();
	// return this.GlobalBest;
	// }

	/**
	 * ���µģ�����long term,�������׼��
	 * 
	 * @return BNGraph
	 * @throws IOException
	 */
	public BNGraph genArcTabuNew() throws IOException {
		this.LogOut = CommonTools.getPrintWriter("c:\\TBN", "tabuarc.txt");
		this.LogOut.println("���µģ�����long term,�������׼��");

		BNGraph currentSolution = (BNGraph) this.initSolution.clone();
		int i = 0;
		do {
			boolean tag = true;
			Queue neighS = this.genNeighSolution(currentSolution);
			if (debug) {
				this.LogOut.print("ȫ����������ֵ��" + this.GlobalBest.K2Score);
				this.LogOut.println("  ��ǰ�������ֵ��" + currentSolution.K2Score);
				this.LogOut.println(this.tabulist);
			}

			while (tag) {
				OperRecord oper = (OperRecord) (neighS.poll());
				if (debug) {
					this.LogOut.println("������ " + oper);
				}
				if (this.tabulist.isTabu(oper)) // ������
				{
					if (debug) {
						this.LogOut.println("������");
					}

					if (this.al.isAspirate(oper)) // �ƽ�
					{
						if (debug) {
							this.LogOut.println("�ƽ�");
							this.LogOut.println(this.al);
						}
						this.execOper(currentSolution, oper);
						if (currentSolution.K2Score > this.GlobalBest.K2Score) {
							if (debug) {
								this.LogOut.println("����ȫ�����Ž�");
							}
							this.GlobalBest = (BNGraph) currentSolution.clone();
							this.GlobalBest.K2Score = currentSolution.K2Score;
							this.bestOccur = i;
						}
						// ���½��ɱ�
						if (debug) {
							this.LogOut.println("���½��ɱ�,�ƽ���,Long-Term");
						}
						this.updateStatus(oper, this.GlobalBest);
						tag = false;
					} else // ����������׼��
					{
						this.LogOut.println("�������ƽ�׼��");
					}
				} else // ��,���½⣬���½��ɱ�
				{
					this.LogOut.println("û�б�����");
					this.execOper(currentSolution, oper);
					if (currentSolution.K2Score > this.GlobalBest.K2Score) {
						if (debug) {
							this.LogOut.println("����ȫ�����Ž�");
						}						
						this.GlobalBest = (BNGraph) currentSolution.clone();
						this.GlobalBest.K2Score = currentSolution.K2Score;
						this.bestOccur = i;
					}
					// ���½��ɱ�
					if (debug) {
						this.LogOut.println("���½��ɱ�,�ƽ���,Long-Term");
					}
					this.updateStatus(oper, this.GlobalBest);
					tag = false;
				}
			}
			i++;
		} while (i < this.maxIterTimes);
		this.LogOut.close();
		return this.GlobalBest;
	}

	public BNGraph goTBN() {
		BNGraph currentSolution = (BNGraph) this.initSolution.clone();
		// generate neighborhood solution
		int i = 0;
		while (i < this.maxIterTimes) {
			boolean tag = true;
			Queue neighS = this.genNeighSolution(currentSolution);
			while (tag) {
				OperRecord oper = (OperRecord) (neighS.poll());
				if (this.tabulist.isTabu(oper)) // ������
				{
					if (this.isAspirate(oper)) // �ƽ�
					{
						this.execOper(currentSolution, oper);
						if (currentSolution.K2Score > this.GlobalBest.K2Score) {
							this.GlobalBest = (BNGraph) currentSolution.clone();
							this.GlobalBest.K2Score = currentSolution.K2Score;
							this.bestOccur = i;
						}
						// ���½��ɱ�
						this.updateStatus(oper, this.GlobalBest);
						tag = false;
					} else // ����������׼��
					{
//						System.out.println("�������ƽ�׼��");
					}
				} else // û�н���,���½�
				{
					this.execOper(currentSolution, oper);
					if (currentSolution.K2Score > this.GlobalBest.K2Score) {
						this.GlobalBest = (BNGraph) currentSolution.clone();
						this.GlobalBest.K2Score = currentSolution.K2Score;
						this.bestOccur = i;
					}
					// ���½��ɱ�
					this.updateStatus(oper, this.GlobalBest);
					tag = false;
				}
//				System.out.println(currentSolution.K2Score);
//				TBN.log.println(currentSolution.K2Score+",");
			}
			
//			if((i % (this.maxIterTimes/2)) == 0)
//			{
//				this.GlobalBest= this.opt(this.GlobalBest, this.tabulist.bestArcCount, 300);
//			}

			i++;
		}
		return this.GlobalBest;
	}
	
	public BNGraph goTBNCI() {
		BNGraph currentSolution = (BNGraph) this.initSolution.clone();
		// generate neighborhood solution
		int i = 0;
		//apply CItest
		
		// �������ݼ�
		K2.calcInf(null);
		K2.CITest(null);
		
		
		while (i < this.maxIterTimes) {
			boolean tag = true;
			Queue neighS = this.genNeighSolutionCI(currentSolution);
			while (tag) {
				OperRecord oper = (OperRecord) (neighS.poll());
				if (this.tabulist.isTabu(oper)) // ������
				{
					if (this.isAspirate(oper)) // �ƽ�
					{
						this.execOper(currentSolution, oper);
						if (currentSolution.K2Score > this.GlobalBest.K2Score) {
							this.GlobalBest = (BNGraph) currentSolution.clone();
							this.GlobalBest.K2Score = currentSolution.K2Score;
							this.bestOccur = i;
						}
						// ���½��ɱ�
						this.updateStatus(oper, this.GlobalBest);
						tag = false;
					} else // ����������׼��
					{
//						System.out.println("�������ƽ�׼��");
					}
				} else // ��,���½�
				{
					this.execOper(currentSolution, oper);
					if (currentSolution.K2Score > this.GlobalBest.K2Score) {
						this.GlobalBest = (BNGraph) currentSolution.clone();
						this.GlobalBest.K2Score = currentSolution.K2Score;
						this.bestOccur = i;
					}
					// ���½��ɱ�
					this.updateStatus(oper,this.GlobalBest);
					tag = false;
				}
//				System.out.println(currentSolution.K2Score);
//				TBN.log.println(currentSolution.K2Score+",");
			}
			i++;
		}
		return this.GlobalBest;
	}

	/**
	 * ���¸���״̬
	 * 
	 * @param oper
	 *            OperRecord
	 * @param curbest TODO
	 */
	private void updateStatus(OperRecord oper, BNGraph curbest) {
		
		this.tabulist.add(oper);
		this.tabulist.updateBestArcCount(curbest);
		this.al.add(oper);
	
	}

	private BNGraph opt(BNGraph g, int[][] count, int thredhold)
	{
		BNGraph best = new BNGraph(g.getVexNum());
		best.K2Score = Double.NEGATIVE_INFINITY;
		
		BNGraph cur = (BNGraph)g.clone();
		for(int i = 0; i < count.length; i++)
		{
			for(int j = 0; j < count[0].length; j++)
			{
				if(count[i][j] < thredhold)
				{
					cur.AddArc(i, j);
					double curscore = cur.calcTotalK2Score(this.score);
					if(curscore > best.K2Score)
					{
						best = (BNGraph)cur.clone();
						best.K2Score = cur.K2Score;
					}
					cur.DelArc(i, j);
					
				}
			}
		}
		return best;
	}
	
	

	/**
	 * execute operate
	 * 
	 * @param g
	 *            BNGraph
	 * @param o
	 *            OperRecord
	 */
	private void execOper(BNGraph g, OperRecord o) {
		g.K2Score = o.score;
		if (debug) {
			// System.err.println("ִ�в���" + o);
//			this.LogOut.println("ִ�в���" + o);
		}
		switch (o.tag) {
		case ADD:
			g.AddArc(o.from, o.to);
			break;
		case DEL:
			g.DelArc(o.from, o.to);
			break;
		case REV:
			g.DelArc(o.from, o.to);
			g.AddArc(o.to, o.from);
			break;
		default:
			System.err.println("should not be here");
		}
	}

	/**
	 * generate neighborehood
	 * 
	 * @param initSolution
	 *            BNGraph
	 * @return Queue
	 */
	private Queue genNeighSolution(BNGraph initSolution) {
//		this.LogOut.println("\r\n����������");
		Queue neighS = new PriorityQueue();
		BNGraph tempS = (BNGraph) initSolution.clone();
		this.genFromADD(neighS, tempS);
		this.genFromDEL(neighS, tempS);
		this.genFromREV(neighS, tempS);
//		System.out.println("neigh size:"+neighS.size());
		return neighS;
	}

//	private Queue genNeighSolutionFirskK(BNGraph initSolution) {
////		this.LogOut.println("\r\n����ǰK������");
//		Queue neighS = new PriorityQueue();
//		OperRecord oper;
//		BNGraph tempS = (BNGraph) initSolution.clone();
//
//		Queue[] tempQueue = new Queue[3];
//		tempQueue[0] = this.genADD(tempS);
//		tempQueue[1] = this.genDel(tempS);
//		tempQueue[2] = this.genREV(tempS);
//
//		for (int i = 0; i < tempQueue.length; i++) {
//			for (int j = 0; j < this.firstK; j++) {
//
//				oper = (OperRecord) tempQueue[i].poll();
//				if (oper != null)
//					neighS.add(oper);
//
//			}
//
//		}
//		System.out.println("����ĳ��ȣ�" + neighS.size());
//		return neighS;
//	}

	//
//	/**
//	 * ���ɼӱ����򣬷��ض���
//	 * 
//	 * @param tempS
//	 *            BNGraph
//	 * @return Queue
//	 */
//
//	private Queue genADD(BNGraph tempS) {
//		Queue queueAll = new PriorityQueue();
//		double oriK2Score = tempS.K2Score;
//		for (int i = 0; i < K2.VEXNUM; i++) {
//			// ��ʼ����ѡ��
//			ArrayList candidate = new ArrayList();
//			for (int j = 0; j < K2.VEXNUM; j++)
//				candidate.add(j);
//			BNNode temp = tempS.GetNode(i);
//			// ɾ�����ϸ�Ľڵ�
//			ArrayList ancestor = temp.GetAncestorNodesIndex();
//			candidate.removeAll(ancestor);
//			// System.out.println("��ѡ����"+candidate);
//			double tempResult;
//			// ADD:i��ǰ�ڵ㣬j��ѡ�ĸ��׽ڵ�
//			for (int j = 0; j < candidate.size(); j++) {
//				int jFrom = (Integer) candidate.get(j);
//				tempS.AddArc(jFrom, i);
//				tempResult = tempS.calcTotalK2Score(score);
//				// System.out.println(tempResult);
//				queueAll.add(new OperRecord(tempResult, jFrom, i, TBN.tag.ADD));
//				tempS.DelArc(jFrom, i);
//			}
//		}
//		tempS.K2Score = oriK2Score;
//		return queueAll;
//	}
//	
//	private Queue genDel(BNGraph tempS) {
//		Queue queueAll = new PriorityQueue();
//		double oriK2Score = tempS.K2Score;
//		for (int i = 0; i < K2.VEXNUM; i++) {
//			BNNode temp = tempS.GetNode(i);
//			ArrayList parent = temp.GetParentNodesIndex();
//			for (int j = 0; j < parent.size(); j++) {
//				int jFrom = (Integer) parent.get(j);
//				tempS.DelArc(jFrom, i);
//				double tempResult = tempS.calcTotalK2Score(score);
//				queueAll.add(new OperRecord(tempResult, jFrom, i, TBN.tag.DEL));
//				tempS.AddArc(jFrom, i);
//
//			}
//		}
//		tempS.K2Score = oriK2Score;
//		return queueAll;
//	}
//	
//	/**
//	 * 
//	 * @param neighS
//	 *            Queue
//	 * @param tempS
//	 *            BNGraph
//	 */
//	private Queue genREV(BNGraph tempS) {
//		double tempScore = tempS.K2Score;
//		Queue queueAll = new PriorityQueue();
//		for (int i = 0; i < K2.VEXNUM; i++) {
//			BNNode node = tempS.GetNode(i);
//			ArrayList<Integer> parent = node.GetParentNodesIndex();
//			for (int j = 0; j < parent.size(); j++) {
//				int jFrom = parent.get(j);
//				tempS.DelArc(jFrom, i);
//				ArrayList<Integer> AncestorAfter = node.GetAncestorNodesIndex();
//				if (!AncestorAfter.contains(jFrom)) // ������
//				{
//					tempS.AddArc(i, jFrom);
//					double tempResult = tempS.calcTotalK2Score(score);
//					queueAll.add(new OperRecord(tempResult, jFrom, i,
//							TBN.tag.REV));
//					tempS.DelArc(i, jFrom);
//				} else {
//				}
//				tempS.AddArc(jFrom, i);
//			}
//		}
//		tempS.K2Score = tempScore;
//		return queueAll;
//	}
//	
	/**
	 * 
	 * @param initSolution
	 *            BNGraph
	 * @return Queue
	 */
	private Queue genNeighSolutionCI(BNGraph initSolution) {
		Queue neighS = new PriorityQueue();
		BNGraph tempS = (BNGraph) initSolution.clone();
		this.genFromADDCI(neighS, tempS);
		this.genFromDEL(neighS, tempS);
		this.genFromREV(neighS, tempS);
		// this.genFromREV(neighS,tempS);
		// while(neighS.isEmpty())
		// {
		// System.out.println();
		// }
		return neighS;
	}

	/**
	 * �ӱ�����
	 * 
	 * @param neighS
	 *            Queue
	 * @param tempS
	 *            BNGraph
	 */
	private void genFromADD(Queue neighS, BNGraph tempS) {
		double oriK2Score = tempS.K2Score;
		for (int i = 0; i < K2.VEXNUM; i++) {
			// ��ʼ����ѡ��
			ArrayList candidate = new ArrayList();
			for (int j = 0; j < K2.VEXNUM; j++)
				candidate.add(j);
			BNNode temp = tempS.GetNode(i);
			// ɾ�����ϸ�Ľڵ�
			ArrayList parent = temp.GetParentNodesIndex();
			ArrayList decedant = temp.GetDescendantNodesIndex();
			candidate.removeAll(parent);
			candidate.removeAll(decedant);
//			 System.out.println("��ǰ�ڵ㣺"+i+"���"+descendant+",��ѡ����"+candidate);
			// ADD:i��ǰ�ڵ㣬j��ѡ�ĸ��׽ڵ�
			for (int j = 0; j < candidate.size(); j++) {
				int jFrom = (Integer) candidate.get(j);
				tempS.AddArc(jFrom, i);
				
				double tempResult = this.score.calcGraphScore(tempS);
				// System.out.println(tempResult);
				neighS.add(new OperRecord(tempResult, jFrom, i, TBN.tag.ADD));
				tempS.DelArc(jFrom, i);
			}
		}
		tempS.K2Score = oriK2Score;
	}


	private void genFromADDCI(Queue neighS, BNGraph tempS) {
		double oriK2Score = tempS.K2Score;
		for (int i = 0; i < K2.VEXNUM; i++) {
			// ��ʼ����ѡ��
			ArrayList candidate = new ArrayList();
			for (int j = 0; j < K2.VEXNUM; j++)
				candidate.add(j);
			BNNode temp = tempS.GetNode(i);

			// ɾ�����ϸ�Ľڵ�
			ArrayList descendant = temp.GetDescendantNodesIndex();
			ArrayList parent = temp.GetParentNodesIndex();
			candidate.removeAll(descendant);
			candidate.removeAll(parent);
			// System.out.println("��ѡ����"+candidate);
			double tempResult;
			// ADD:i��ǰ�ڵ㣬j��ѡ�ĸ��׽ڵ�
			for (int j = 0; j < candidate.size(); j++) {
				int jFrom = (Integer) candidate.get(j);
				if (K2.ChiSquare[jFrom][i] == 1) {
					tempS.AddArc(jFrom, i);
					tempResult = this.score.calcGraphScore(tempS);

					// System.out.println(tempResult);
					neighS
							.add(new OperRecord(tempResult, jFrom, i,
									TBN.tag.ADD));
					tempS.DelArc(jFrom, i);
				}
			}
		}
		tempS.K2Score = oriK2Score;
	}

	/**
	 * ɾ������
	 * 
	 * @param neighS
	 *            Queue
	 * @param tempS
	 *            BNGraph
	 */
	private void genFromDEL(Queue neighS, BNGraph tempS) {
		double oriK2Score = tempS.K2Score;
		for (int i = 0; i < K2.VEXNUM; i++) {
			BNNode temp = tempS.GetNode(i);
			ArrayList parent = temp.GetParentNodesIndex();
			for (int j = 0; j < parent.size(); j++) {
				int jFrom = (Integer) parent.get(j);
				tempS.DelArc(jFrom, i);
				double tempResult = this.score.calcGraphScore(tempS);
				neighS.add(new OperRecord(tempResult, jFrom, i, TBN.tag.DEL));
				tempS.AddArc(jFrom, i);

			}
		}
		tempS.K2Score = oriK2Score;
	}

	

	/**
	 * ��ת����
	 * 
	 * @param neighS
	 *            Queue
	 * @param tempS
	 *            BNGraph
	 */
	private void genFromREV(Queue neighS, BNGraph tempS) {
		double tempScore = tempS.K2Score;
		for (int i = 0; i < K2.VEXNUM; i++) {
			BNNode node = tempS.GetNode(i);
			ArrayList<Integer> parent = node.GetParentNodesIndex();
			for (int j = 0; j < parent.size(); j++) {
				int jFrom = parent.get(j);
				tempS.DelArc(jFrom, i);
				ArrayList<Integer> AncestorAfter = node.GetAncestorNodesIndex();
				if (!AncestorAfter.contains(jFrom)) // ������
				{
					tempS.AddArc(i, jFrom);
					double tempResult = this.score.calcGraphScore(tempS);
					neighS.add(new OperRecord(tempResult, jFrom, i,
									TBN.tag.REV));
					tempS.DelArc(i, jFrom);
				} else {
				}
				tempS.AddArc(jFrom, i);
			}
		}
		tempS.K2Score = tempScore;
	}

	

	/**
	 * �ж��Ƿ���������׼��
	 * 
	 * @param oper
	 *            OperRecord
	 * @return boolean
	 */
	private boolean isAspirate(OperRecord oper) {
		boolean tag = false;
		if (oper.score > this.GlobalBest.K2Score)
			tag = true;
		return tag;
	}

}
