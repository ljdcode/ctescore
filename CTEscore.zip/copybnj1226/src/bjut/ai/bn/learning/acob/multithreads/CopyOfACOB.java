package bjut.ai.bn.learning.acob.multithreads;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;
import java.util.TreeSet;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import bjut.ai.bn.learning.acob.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.HillClimbing;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.BICScore;
import bjut.ai.bn.score.MDLScore;
import bjut.ai.bn.score.Score;
import bjut.ai.bn.score.patel;

/**
 * ���⣺1ͼ����ȡ�����Ƚڵ� 2ͼʵ��Compareble�ӿڶ����ֺ���ֵ
 * <p>
 * Title:
 * </p>
 * 
 * <p>
 * Description:
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * 
 * <p>
 * Company:
 * </p>
 * 
 * @author not attributable
 * @version 1.0
 */
public class CopyOfACOB {

	public double[][] tempH = null;
	public double[] noParVexK2Value = new double[K2.VEXNUM];
	// ȫ����Ϣ�ؾ���
	public double GlobalPheromoneMatrix[][] = new double[K2.VEXNUM][K2.VEXNUM];

	public int bestOccur = 0;
	public long[] bestOccurTime = new long[200];
	private static int solutionCount = 0;
	public ArrayList<BNGraph> BestSolutions;
	public static int LogK2ScoreCount = 0;
	/*
	 * public SingleAntB(double[][] apheromone, double analpha, double abeta,
	 * double arou, double aq0, double atao0, int aVexNum,int ID)
	 */
	public int vexnum;
	public Score score = null;
	public BNGraph BestSolution;

	private BNGraph gk2sn;
	private int tStep;
	private int tMaxStep;
	private int antNum;
	private double alpha;
	private double beta;
	private double rou;
	private double q0;
	private double tao0; // ��ʼ��Ϣ��
    private int currentI; //��¼����
    
    private double thred; //��¼����
    private double K; //��¼����
    
	//public static double[][] ta1; 
	//public static double[][] ta2;
	//public static double[][] ta3;
	//public static double[][] ta4;
	
	
	private K2.TYPE type;

	private double[][] allPh;// ȫ�ֶ��������Ϣ��

	private java.util.ArrayList<Double> BestScore; // ÿһ�������ŷ�ֵ
	private java.util.TreeSet<Integer> setOpted; // �Ѿ������Ż�������ֵ
	private java.util.Random AnnealRandom = new Random();


	/**
	 * tStep�����Ż��Ĵ��� tMaxStep����������
	 * 
	 * @param tStep
	 *            int
	 * @param tMaxStep
	 *            int
	 */
	public CopyOfACOB(BNGraph gk2sn, double alpha, double beta, double rou,
			double q0, int tStep, int tMaxStep, int antNum, K2.TYPE type1,
			Score score, patel p, double th, double k) {
		// //���k2sn�Ľ� ��ʽ��
		this.score = score;

		this.gk2sn = gk2sn;
		this.vexnum = gk2sn.getVexNum();
		this.tempH = new double[vexnum][vexnum];
		this.tao0 = 1 / (vexnum * Math.abs(this.score
				.calcGraphScore(this.gk2sn)));
		this.BestSolution = gk2sn;
		// ��ʱ
		this.antNum = antNum;
		this.tMaxStep = tMaxStep;
		this.tStep = tStep;
		this.alpha = alpha;
		this.beta = beta;
		this.rou = rou;
		this.q0 = q0;
		this.BestSolutions = new ArrayList<BNGraph>();
		this.type = type1;
		
		this.thred=th; //�ٷ�λ��ֵ
		this.K=k; //kappa��ֵ
		
		switch (type) {
		case ORI:
			//System.err.println("ԭʼ");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();
			this.initheuristicInfo();
			this.initalGlobalPheromene(this.tao0);
			break;
		case SA:
			System.err.println("ģ���˻��Ż�");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();
			this.initheuristicInfo();
			this.initalGlobalPheromene(this.tao0);
			break;

		case CI:
			System.err.println("CI����");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();

			this.initheuristicInfo();
			this.initalGlobalPheromene(this.tao0);
			CIConstrain(((K2) score).getRecord());
			break;
			
		case PC:
			System.err.println("patel����Լ��");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();
			
			
	
			this.initheuristicInfo();
			this.initalGlobalPheromene(this.tao0);
		    this.pConstrain(p);
			

			break;

		}
	
	}

	public void setScoreMetric(Score s) {
		this.score = s;
	}

	public void initalGlobalPheromene(double tao0) {
		for (int i = 0; i < this.GlobalPheromoneMatrix.length; i++) {
			for (int j = 0; j < this.GlobalPheromoneMatrix[i].length; j++) {
				if (i != j) {
					this.GlobalPheromoneMatrix[i][j] = tao0;
				} else {
					this.GlobalPheromoneMatrix[i][j] = Double.NEGATIVE_INFINITY;
				}

			}
		}
	}

	public void initheuristicInfo() {
		BNGraph temp = new BNGraph(this.vexnum);
		ArrayList<Integer> anodelist = new ArrayList<Integer>(); // ��ʱ
		//System.out.println("��ʼ��������Ϣ����");
		long start = System.currentTimeMillis();
		for (int i = 0; i < this.vexnum; i++) {
			noParVexK2Value[i] = this.score.calcScore(i, anodelist);
			//System.out.println("������Ϣ����"+noParVexK2Value[i]);
			for (int j = 0; j < this.vexnum; j++) {
				if (i != j) {
					anodelist.add(j);
					this.tempH[i][j] = this.score.calcScore(temp.GetNode(i)
							.GetNodeId(), anodelist)
							- noParVexK2Value[i];
					anodelist.remove(0);
				} else
					this.tempH[i][j] = Double.NEGATIVE_INFINITY;
				
				
			//	System.out.println("������Ϣ"+i+j+" :" +this.tempH[i][j]);
			}
		}

		long end = System.currentTimeMillis();
		//System.out.format("���,����[%d]����\n", end - start);

		
	}
	
	

	
	/**
	 * ����CI����
	 */
	public void CIConstrain(String[][] data) {
		K2.calcInf(data);
		K2.CITest(data);
		System.out.println("CIѹ��");
		for (int i = 0; i < K2.VEXNUM; i++) {
			for (int j = 0; j < K2.VEXNUM; j++) {
				if (K2.ChiSquare[i][j] == 0) {
					this.tempH[i][j] = Double.NEGATIVE_INFINITY;
				}
			}
		}
	}
	
	
	/**
	 * ����patelԼ��
	 */
	public void pConstrain(patel p) {
		System.out.println("Patelѹ��");
		for (int i = 0; i < K2.VEXNUM; i++) {
			for (int j = 0; j < K2.VEXNUM; j++) {	
			//	System.out.println(p.kappa[i][j]+","+"K:"+K);
				if (p.kappa[i][j] <K) {
				//	System.out.println("xiaole");
					this.tempH[i][j] = Double.NEGATIVE_INFINITY;
     				
				}
			//	System.out.print(tempH[i][j]+" ");
				//System.out.print(p.kappa[i][j]+" ");
			}
		//System.out.println(" ");
		}
	}
	
	
	public BNGraph getBestSolution() {
		Collections.sort(this.BestSolutions);
		return this.BestSolutions.get(this.BestSolutions.size() - 1);
	}

	/**
	 * ����ȫ����Ϣ��
	 * 
	 * @param g
	 *            BNGraph
	 */
	private void updateGlobalPheromone(final BNGraph g) {
		// System.out.println("ȫ����Ϣ�ظ���");
		double bestSolutionCost = Math.abs(1 / g.calcTotalK2Score(this.score));
		ArrayList al = new ArrayList();
		for (int i = 0; i < K2.VEXNUM; i++) {
			al = g.GetNode(i).GetParentNodesIndex();
			for (int j = 0; j < al.size(); j++) {
				this.GlobalPheromoneMatrix[i][(Integer) al.get(j)] = (1 - this.rou)
						* this.GlobalPheromoneMatrix[i][(Integer) al.get(j)]
						+ this.rou * bestSolutionCost;
			}
		}
	}

	// public static void CIConstrainByValue(double base)
	// {
	// K2.CITestByValue(base);
	// for (int i = 0; i < K2.VEXNUM; i++)
	// {
	// for (int j = 0; j < K2.VEXNUM; j++)
	// {
	// if (K2.ChiSquare[i][j] == 0)
	// {
	// this.tempH[i][j] = Double.NEGATIVE_INFINITY;
	// }
	// }
	// }
	//
	// }
	/**
	 * ��Ϣ�ص���ʾ
	 */
	private void printPheromone2(int m_i, int m_j) {
	//�������ֵ��Сֵ 
				
		//���
		for(int i=0;i<m_i;i++)
		{
		for(int j=0;j<m_j;j++)
		   {
			System.out.print(GlobalPheromoneMatrix[j][i]);
			System.out.print(" ");
			}
		System.out.print("\n");
		}
		
	}
	
	public void printPheromone(int m_i, int times, double sdMatrix[][]) {
		//�������ֵ��Сֵ 
		        double sum=0.0;
				double min=0.0;
                int count=0;
                double f=0.0;
                double deta=0.0;
                int m_j=m_i;
			 
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				if(GlobalPheromoneMatrix[j][i]>=0)
				{
			       sum+=GlobalPheromoneMatrix[j][i];
			       count++;
				}
				
			   }
			       
			}
			min=sum/count;
			
			//System.out.print(min);
			
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				if(GlobalPheromoneMatrix[j][i]>=0)
				{
					f += Math.sqrt((GlobalPheromoneMatrix[j][i] -min) *(GlobalPheromoneMatrix[j][i] -min));
			     	
					}
				
			   }
			       
			}
			deta=f/ Math.sqrt(count);
			//��һ��
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				GlobalPheromoneMatrix[j][i]=(GlobalPheromoneMatrix[j][i]-min)/(deta);
			   }
			}		
					
			//���
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				sdMatrix[j][i]+=GlobalPheromoneMatrix[j][i];
			//	System.out.print(GlobalPheromoneMatrix[j][i]);
			//	System.out.print(" ");
				}
		//	System.out.print("\n");
			}
			
			//���
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				System.out.print(sdMatrix[j][i]/times);  //���ж��ٴ�
				System.out.print(" ");
				}
			System.out.print("\n");
			}
			
		}
	
	/**
	 * ����BayesianNet
	 * 
	 * @return BNGraph
	 */
	public BNGraph findBestBayesianNet(patel p) {
		long start = System.currentTimeMillis();
		BNGraph G_b;
		this.BestScore.clear();
		this.setOpted.clear();
		currentI=0;
		
		for (int t = 0; t < tMaxStep; t++) {
			ACOB.solutionCount = 0;
			
			for (int k = 0; k < antNum; k++) {
				// System.out.format("���ɵ�[%d]ֻ����\n", count);
				
				
				AntB temp = new AntB(this.alpha, this.beta,
						this.rou, this.q0,
						this.tao0, K2.VEXNUM, k,
						this.type, this.tempH,
						this.score, this.GlobalPheromoneMatrix,
						this.noParVexK2Value, this.BestSolutions,p);
				temp.run();
		
				this.allPh=this.GlobalPheromoneMatrix;
				
				ACOB.solutionCount++;
				// System.out.println("��������⻨����" + (end - start) + "ms");
			}
           
			
			// System.out.println("(����)�⼯�ϵ�����" + ACOB.bestSolution.length);
			if (this.type == K2.TYPE.OP || this.type == K2.TYPE.SA) {
				// ����Ӧ�Ż�
				// AdaptHillClimbing();
				// ģ���˻��Ż�
				if ((t % tStep) == 0 && t != 0) {
					System.out.println("����ģ���˻��Ż�..δ��ɵ�");
				}
			} else {
				// �����Ż�
				if ((t % tStep) == 0 && t != 0) {
				//	System.out.println("�����Ż�" + t);
					for (int i = 0; i < this.BestSolutions.size(); i++) {
						this.BestSolutions.set(i, this
								.HillClimbing(this.BestSolutions.get(i)));						
					}

				}
			}
			
			
			G_b = this.getBestSolution();
			long end = System.currentTimeMillis();
			long interTime = end - start;
			bestOccurTime[t] = interTime;
			if (G_b.K2Score > this.BestSolution.K2Score) {
				this.BestSolution = G_b;
				bestOccur = t;
			}

			this.updateGlobalPheromone(this.BestSolution);
			// LogOut4.println(this.BestSolution.K2Score);
			// LogOut4.close();
			// sb.append(this.BestSolution.K2Score + ",");

			// �ж��Ƿ��˳�
			
		//	System.out.println(this.bestOccur);
			currentI=t;
		
			if (this.canStop()) {
				
				break;
			}
		//	System.out.println(currentI);
		
		}
		// ����Ż�
		
		if (this.type == K2.TYPE.OP || this.type == K2.TYPE.SA) {
		} else {
			this.localOptimizate();
		}

		return this.BestSolution;
	}

	

	public BNGraph findBestBayesianNet1(patel p) {
		long start = System.currentTimeMillis();
		BNGraph G_b;
		this.BestScore.clear();
		this.setOpted.clear();
		currentI=0;
		/*
		for (int i = 0; i < K2.VEXNUM; i++) {
			for (int j = 0; j < K2.VEXNUM; j++) {	
				System.out.print(p.kappa[i][j]+" ");
			}
		System.out.println(" ");
		
		}*/
		
		for (int t = 0; t < tMaxStep; t++) {
			ACOB.solutionCount = 0;
			for (int k = 0; k < antNum; k++) {
				// System.out.format("���ɵ�[%d]ֻ����\n", count);
				CopyOfAntB temp = new CopyOfAntB(this.alpha, this.beta,
						this.rou, this.q0,
						this.tao0, K2.VEXNUM, k,
						this.type, this.tempH,
						this.score, this.GlobalPheromoneMatrix,
						this.noParVexK2Value, this.BestSolutions, p);
				
				temp.run1(p);
				//temp.run();
				
				this.allPh=this.GlobalPheromoneMatrix;
				
				ACOB.solutionCount++;
				// System.out.println("��������⻨����" + (end - start) + "ms");
			}

			
			// System.out.println("(����)�⼯�ϵ�����" + ACOB.bestSolution.length);
			if (this.type == K2.TYPE.OP || this.type == K2.TYPE.SA) {
				// ����Ӧ�Ż�
				// AdaptHillClimbing();
				// ģ���˻��Ż�
				if ((t % tStep) == 0 && t != 0) {
					System.out.println("����ģ���˻��Ż�..δ��ɵ�");
				}
			} else {
				// �����Ż�
				if ((t % tStep) == 0 && t != 0) {
				//	System.out.println("�����Ż�" + t);
					for (int i = 0; i < this.BestSolutions.size(); i++) {
						this.BestSolutions.set(i, this
								.HillClimbing(this.BestSolutions.get(i)));						
					}

				}
			}
			
			for (int i = 0; i < this.BestSolutions.size(); i++) {
				this.BestSolutions.set(i, this.BestSolutions.get(i));						
			}
			
			
			G_b = this.getBestSolution();

			if (G_b.K2Score > this.BestSolution.K2Score) {
				this.BestSolution = G_b;
				bestOccur = t;
			}

			this.updateGlobalPheromone(this.BestSolution);
			// LogOut4.println(this.BestSolution.K2Score);
			// LogOut4.close();
			// sb.append(this.BestSolution.K2Score + ",");

			// �ж��Ƿ��˳�
			
		//	System.out.println(this.bestOccur);
			currentI=t;
		
			if (this.canStop()) {
				
				break;
			}
		//	System.out.println(currentI);
		
		}
		// ����Ż�
		
		if (this.type == K2.TYPE.OP || this.type == K2.TYPE.SA) {
		} else {
			this.localOptimizate();
		}

		return this.BestSolution;
		
		
	}

	public BNGraph findBestBayesianNet2() {
		long start = System.currentTimeMillis();
		BNGraph G_b = new BNGraph();
		this.BestScore.clear();
		this.setOpted.clear();
		currentI=0;

		this.BestSolutions.add(G_b);
		
		for (int t = 0; t < tMaxStep; t++) {
			ACOB.solutionCount = 0;

					for (int i = 0; i < this.BestSolutions.size(); i++) {
						this.BestSolutions.set(i, this.HillClimbing(this.BestSolutions.get(i)));						
					}


			
			
			for (int i = 0; i < this.BestSolutions.size(); i++) {
				this.BestSolutions.set(i, this.BestSolutions.get(i));						
			}
			
			
			G_b = this.getBestSolution();

			if (G_b.K2Score > this.BestSolution.K2Score) {
				this.BestSolution = G_b;
				bestOccur = t;
			}

		//	this.updateGlobalPheromone(this.BestSolution);

			currentI=t;
		
			if (this.canStop()) {
				
				break;
			}
		//	System.out.println(currentI);
		
		}
		// ����Ż�
		
		if (this.type == K2.TYPE.OP || this.type == K2.TYPE.SA) {
		} else {
			this.localOptimizate();
		}

		return this.BestSolution;
		
		
	}
	
	static int MaxEqualStep = 5;

	private boolean canStop() {
		boolean stop = false;

		int current = currentI; // ��ǰ����
		if (current - this.bestOccur +1 > ACOB.MaxEqualStep) {
			//System.err.println("stop at:" + current);
			stop = true;
		}

		return stop;
	}
	
	/**
	 * ��ɽ�Ż�
	 * 
	 * @param G_k
	 *            BNGraph
	 * @return BNGraph
	 */

	public BNGraph HillClimbing(BNGraph G_k) {
		HillClimbing hill = new HillClimbing(G_k, this.score);
		if (this.type == K2.TYPE.OP) {
			G_k = hill.OptimizeBN_CI();
		} else {
			G_k = hill.OptimizeBN();
		}
		return G_k;
	}

	/**
	 * �ֲ��Ż�
	 */
	public void localOptimizate() {
		BNGraph temp = new BNGraph(this.vexnum);
		//System.out.println("���ľֲ��Ż�");
		for (int i = 0; i < this.BestSolutions.size(); i++) {
			this.BestSolutions.set(i, this.HillClimbing(this.BestSolutions
					.get(i)));						
		}
		temp = this.getBestSolution();
		if (temp.getScore() > this.BestSolution.getScore()) {
			this.BestSolution = temp;
		}

	}
	
	

	private static java.lang.StringBuilder sb;

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		sb = new java.lang.StringBuilder();
		try {
			File file =new File("E:\\Disdata\\sim1-3results2.txt");
			Writer out =new FileWriter(file);
			String data="888";
			
		    double sdMatrix[][] = new double[K2.VEXNUM][K2.VEXNUM];
			// ���ݼ���Ϣ
			System.out.println("ЧӦ�����������ɣ�");
			String DatasetFile = "E:\\Disdata\\sim1-3.txt";//��Ҫ��

     		int Vexnum = 5;//��Ҫ��
      		int DNum =  10000;//��Ҫ��mci
     		
			int[] DatasetNum = {50000};//��Ҫ��MCI
			int duile=0;
			 
			// ʵ������
			ArrayList<K2.TYPE> types = new ArrayList<K2.TYPE>();
			types.add(K2.TYPE.ORI);
			
			Iterator it = types.iterator();
			while (it.hasNext()) {
				K2.TYPE SearchType = (K2.TYPE) it.next();
				String type = SearchType.toString();
				for (int count = 0; count < DatasetNum.length; count++) {
					sb.append("\n" + type + DatasetNum[count]);
					
					Score k2 = new K2(DatasetFile, DNum, Vexnum); 
					
					for (int i = 0; i < 100; i++) {
						k2.clearCache();
						// ����־

						BNGraph gk2sn = new BNGraph(Vexnum);
						long start1 = System.currentTimeMillis();						
						
						patel pa = new patel(DatasetFile, DNum, Vexnum);
						ACOB sa = new ACOB(gk2sn, 1.0, 2.0, 0.4, 0.8, 10, 100,10, SearchType, k2, pa, 0.6, 0.2);
						
					//Ѱ�����ű�Ҷ˹��
				    	gk2sn = sa.findBestBayesianNet(pa);
						
				    	data=String.valueOf(gk2sn.getScore());
				    	String data1= "\n";
				    	out.write(data+data1);
								
						System.out.println("Score:"+gk2sn.getScore());
											
					}
					out.close();
				}
			}
				
						
				
			

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}
