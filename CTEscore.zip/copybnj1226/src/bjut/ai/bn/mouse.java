package bjut.ai.bn;

public class mouse {

}
