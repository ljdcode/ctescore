package bjut.ai.bn;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import smile.Network;
import smile.learning.DataSet;
import edu.ksu.cis.bnj.bbn.BBNDiscreteValue;
import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.BBNNode;
import edu.ksu.cis.bnj.bbn.datagen.ForwardSampling;
import edu.ksu.cis.bnj.bbn.inference.InferenceResult;
import edu.ksu.cis.bnj.bbn.inference.ls.LS;
import edu.ksu.cis.kdd.data.Database;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.data.converter.arff.ArffParser;
public class AlarmReader {
	public String FileName;
	public String[][] DataSet;
	public int RecordNum;
	public int AttributeNum;
	public static Hashtable<String, Integer> nodeName2index = null;
	public static Hashtable<Integer, String> index2nodeName = null;
	public static BBNGraph ALARM = BBNGraph.load("data\\alarm.xml");
	public static int[] AlarmNodeDef = { 3, 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 2, 4,
			4, 4, 3, 2, 2, 2, 2, 2, 3, 2, 2, 3, 3, 2, 2, 3, 2, 2, 3, 3, 4, 4,
			4, 4 };
	
	private static int[] orderS2BJUT = { 18, 21, 22, 23, 15, 36, 35, 34, 33, 32, 3,
			16, 17, 25, 19, 20, 30, 11, 31, 10, 26, 28, 5, 4, 24, 0, 29, 27,
			13, 6, 7, 8, 2, 14, 9, 1, 12 };
	
	private static int[] orderBJUT2S = { 25, 35, 32, 10, 23, 22, 29, 30, 31,
			34, 19, 17, 36, 28, 33, 4, 11, 12, 0, 14, 15, 1, 2, 3, 24, 13, 20,
			27, 21, 26, 16, 18, 9, 8, 7, 6, 5 };
	static {
		// index��1��ʼ37������������Щ�ط�Ҫ-1��+1
		nodeName2index = Node2Num("data\\node2num.txt");
		index2nodeName = reverseHashtable(nodeName2index);
	}

	public AlarmReader(String FileName, int RecordNum, int AttributeNum) {
		this.FileName = FileName;
		this.RecordNum = RecordNum;
		this.AttributeNum = AttributeNum;
		DataSet = new String[this.RecordNum][this.AttributeNum];

	}
	
	public AlarmReader() {
	};

	public String[][] readGeNIeDataToBjutDatanum(String fname) {
		// GeNIe dataset order for bjut dataset
		int[] order = { 18, 21, 22, 23, 15, 36, 35, 34, 33, 32, 3, 16, 17, 25,
				19, 20, 30, 11, 31, 10, 26, 28, 5, 4, 24, 0, 29, 27, 13, 6, 7,
				8, 2, 14, 9, 1, 12 };
		DataSet ds = new DataSet();
		ds.readFile(fname);
		int VARNUM = ds.getVariableCount();
		int DATANUM = ds.getRecordCount();
		String[][] dest = new String[DATANUM][VARNUM];
		for (int i = 0; i < DATANUM; i++) {
			for (int j = 0; j < VARNUM; j++) {
				int value = ds.getInt(j, i);
				dest[i][order[j]] = Integer.toString(value);
			}
		}
		return dest;
	}
	// ����c�е�ȡֵ���,����һ��������
	public TreeSet[] getColumnValue()// c [0,36]
	{
		TreeSet<String>[] ts = new TreeSet[AttributeNum];
		for (int k = 0; k < AttributeNum; k++) {
			ts[k] = new TreeSet();
		}
		for (int i = 0; i < RecordNum - 1; i++) {
			// System.out.print(i+""+"\n");
			for (int j = 0; j < AttributeNum; j++) {
				ts[j].add(DataSet[i][j]);
			}
		}
		return ts;
	}

	public void genGeNleEvidence(String path) {
		PrintWriter pw = CommonTools.getPrintWriter(path);
		for (int i = 0; i < this.DataSet[0].length; i++) {
			pw.append(AlarmReader.index2nodeName.get(i + 1));
			pw.append(",");
			pw.append(DataSet[0][i] + "\n");
		}
		pw.close();
	}
	public TreeSet[] getColumnValue(String[][] data)// c [0,36]
	{
		TreeSet<String>[] ts = new TreeSet[data[0].length];
		for (int k = 0; k < data[0].length; k++) {
			ts[k] = new TreeSet();
		}
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[0].length; j++) {
				ts[j].add(data[i][j]);
			}
		}
		return ts;
	}

	/**
	 * �ṩһ�����ֺ�˳���Ӧ���ļ� ���һ������˳����Э�����ݼ���
	 * 
	 * @param node2numfilepath
	 * @return
	 */
	public String[][] GetBNJDataSet() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		try {
			BufferedReader br = new BufferedReader(
					new FileReader(this.FileName));
			String line = null;
			// ����˳��
			for (int i = 0; i < 39; i++) {
				line = br.readLine();
				if (line != null) {
					String[] strs = line.split(" ");
					if (strs[0].equals("@ATTRIBUTE")) {
						order.add(AlarmReader.nodeName2index
								.get(strs[1]) - 1);
					}
				}
			}

			br.readLine();
			br.readLine();
			line = br.readLine();
			for (int count = 0; count < this.RecordNum; count++) {
				if (line != null) {
					String[] strs = line.split(",");
					String[] curStr = new String[strs.length];
					for (int i = 0; i < strs.length; i++) {
						int index = order.get(i);
						curStr[index] = strs[i];
					}
					this.DataSet[count] = curStr;
					line = br.readLine();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return this.DataSet;

	}

	/**
	 * �ʺ϶�ȡ��׼���ݼ�
	 */
	public String[][] GetDataSet() {
		int row = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader(FileName));
			String line = br.readLine();
			while (line != null && row < RecordNum) {
				line = line.trim();
				DataSet[row] = line.split("[\\s]+");
				line = br.readLine();
				row++;
			}
			br.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return DataSet;
	}

	/**
	 * ����һ��hashtable��Ӧ�ڵ�
	 * 
	 * @param filepath
	 * @return
	 */
	private static Hashtable<String, Integer> Node2Num(String filepath) {
		Hashtable<String, Integer> r = new Hashtable<String, Integer>();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(filepath));
			String line = br.readLine();
			while (line != null) {
				String[] strs = line.split("'");
				r.put(strs[1].trim(), Integer.valueOf(strs[strs.length - 1]));
				line = br.readLine();
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
			r = null;
			br = null;
			return r;
		}
		return r;
	}

	private static Hashtable reverseHashtable(Hashtable<String, Integer> table) {
		Hashtable reversedTable = new Hashtable<Integer, String>();
		Set<String> keys = table.keySet();
		Iterator<String> iter = keys.iterator();
		while (iter.hasNext()) {
			String tempkey = iter.next();
			Integer tempvalue = table.get(tempkey);
			reversedTable.put(tempvalue, tempkey);
		}
		return reversedTable;

	}

	public Hashtable getNodeValues(BBNGraph bbng) {
		Hashtable nodevalues = new Hashtable<String, ArrayList<String>>();
		Set<String> nodes = bbng.getNodeNames();
		Iterator<String> iter = nodes.iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			BBNNode node = (BBNNode) bbng.getNode(key);
			ArrayList<String> al = new ArrayList<String>();
			Set<String> values = (Set<String>) node.getValues();
			Iterator valiter = values.iterator();
			while (valiter.hasNext()) {
				al.add((String) valiter.next());
			}
			nodevalues.put(key, al);
		}
		return nodevalues;
	}

	public void tranK2dataToString(String oriFile, String destiFile,
			String netFile) {

		BBNGraph bbng = BBNGraph.load(netFile);
		Hashtable nodevalue = this.getNodeValues(bbng);

		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			Hashtable temp = AlarmReader.Node2Num("data\\node2num.txt");
			Hashtable indexnode = AlarmReader.reverseHashtable(temp);

			br = new BufferedReader(new FileReader(oriFile));
			bw = new BufferedWriter(new FileWriter(destiFile));

			String line = br.readLine();
			while (line != null) {
				String[] strs = line.trim().split("[\\s]+");
				for (int i = 0; i < strs.length; i++) {
					String key = (String) indexnode.get(i + 1);
					ArrayList<String> tempvalue = (ArrayList<String>) nodevalue
							.get(key);
					String value = tempvalue.get(Integer.parseInt(strs[i]));
					bw.append(value + " ");
				}
				bw.append("\n");
				line = br.readLine();
			}
			br.close();
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
				bw.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * �洢���ݼ�
	 * 
	 * @param dataset
	 * @param filepath
	 */
	public static void saveDataset(String[][] dataset, String filepath) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
			for (int i = 0; i < dataset.length; i++) {
				for (int j = 0; j < dataset[0].length; j++) {
					bw.append(dataset[i][j]);
					bw.append(" ");
				}
				bw.append("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param dataset
	 *            Ҫ��֤��G[][]����ʽ
	 * 
	 * @param filepath
	 */
	public static void saveGDS(String[][] dataset, String filepath) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
			String header = "Anaphylaxis Intubation KinkedTube Disconnect MinVolSet "
					+ "VentMach VentTube VentLung VentAlv ArtCO2 "
					+ "TPR Hypovolemia LVFailure StrokeVolume InsuffAnesth PulmEmbolus "
					+ "Shunt FiO2 PVSat SaO2 Catechol HR CO BP LVEDVolume CVP ErrCauter "
					+ "ErrLowOutput ExpCO2 HRBP HREKG HRSat History MinVol PAP PCWP Press\n";
			bw.append(header);
			for (int i = 0; i < dataset.length; i++) {
				for (int j = 0; j < dataset[0].length; j++) {
					bw.append(dataset[i][j]);
					bw.append(" ");
				}
				bw.append("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * ok
	 * 
	 * @param dataset
	 * @param filepath
	 */
	public static void saveBJUTDS(String[][] dataset, String filepath) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
			for (int i = 0; i < dataset.length; i++) {
				for (int j = 0; j < dataset[0].length; j++) {
					bw.append(dataset[i][j]);
					bw.append(" ");
				}
				bw.append("\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * ok
	 * 
	 * @param gds
	 * @return
	 */
	public static String[][] tranGDS2BjutDS(String[][] gds) {
		int[] order = { 18, 21, 22, 23, 15, 36, 35, 34, 33, 32, 3, 16, 17, 25,
				19, 20, 30, 11, 31, 10, 26, 28, 5, 4, 24, 0, 29, 27, 13, 6, 7,
				8, 2, 14, 9, 1, 12 };
		String[][] bjutds = new String[gds.length][gds[0].length];
		for (int i = 0; i < gds.length; i++) {
			for (int j = 0; j < gds[0].length; j++) {
				bjutds[i][order[j]] = gds[i][j];
			}
		}
		return bjutds;
	}
	
	

	/**
	 * ok
	 * 
	 * @param bjutds
	 * @return
	 */
	public static String[][] tranBjutDS2GDS(String[][] bjutds) {
		int[] order = { 18, 21, 22, 23, 15, 36, 35, 34, 33, 32, 3, 16, 17, 25,
				19, 20, 30, 11, 31, 10, 26, 28, 5, 4, 24, 0, 29, 27, 13, 6, 7,
				8, 2, 14, 9, 1, 12 };
		String[][] gds = new String[bjutds.length][bjutds[0].length];
		for (int i = 0; i < gds.length; i++) {
			for (int j = 0; j < gds[0].length; j++) {
				gds[i][j] = bjutds[i][order[j]];
			}
		}
		return gds;
	}
	
	
	
	
	/**
	 * ȡ��Genile�����ݼ�
	 * 
	 * @param filepath
	 * @param datanum
	 * @return
	 */
	public static String[][] getGDS(String filepath, int datanum) {
		String[][] dest = new String[datanum][];
		int count = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader(filepath));
			br.readLine();
			String curline = br.readLine();
			while (curline != null && count < datanum) {
				String[] temp = curline.split("[\\s]+");
				dest[count] = new String[temp.length];
				System.arraycopy(temp, 0, dest[count], 0, temp.length);
				++count;
				curline = br.readLine();
			}
	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return dest;
	}

	/**
	 * ok ȡ��BJUT���ݼ�
	 * 
	 * @param filepath
	 * @param datanum
	 * @return
	 */
	public static String[][] getBJUTDS(String filepath, int datanum) {
		String[][] dest = new String[datanum][];
		int count = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader(filepath));
			String curline = br.readLine();
			while (curline != null && count < datanum) {
				String[] temp = curline.split("[\\s]+");
				dest[count] = new String[temp.length];
				System.arraycopy(temp, 0, dest[count], 0, temp.length);
				++count;
				curline = br.readLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dest;

	}
	
	
	/**
	 * ȡ��GeNle�����ݼ���GOOD!����bjut����ʽ
	 * 
	 * 
	 * @return
	 */
	public String[][] GetGeNIleDataset() {
		String[][] dest = new String[this.RecordNum][this.AttributeNum];
		int[] order = { 18, 21, 22, 23, 15, 36, 35, 34, 33, 32, 3, 16, 17, 25,
				19, 20, 30, 11, 31, 10, 26, 28, 5, 4, 24, 0, 29, 27, 13, 6, 7,
				8, 2, 14, 9, 1, 12 };
		int count = 0;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(this.FileName));
			br.readLine();
			String line = br.readLine();
			String[] words;
			while (line != null && count < this.RecordNum) {
				words = line.split("[\\s]+");
				for (int i = 0; i < words.length; i++) {
					dest[count][order[i]] = words[i];
				}
				count++;
				line = br.readLine();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dest;
	}
	
	/**
	 * 
	 * @param data
	 * @return
	 */
	public String[][] tranString2Num(String[][] data) {
		String[][] numdata = new String[data.length][data[0].length];
		Hashtable ValueMap = this.conNodeValueMap();
		for (int j = 0; j < data[0].length; j++) {
			String curNodeName = AlarmReader.index2nodeName.get(j + 1);
			Hashtable curValueMap = (Hashtable) ValueMap.get(curNodeName);
			for (int i = 0; i < data.length; i++) {
				numdata[i][j] = (String)curValueMap.get(data[i][j]);
			}
		}
		return numdata;
	}

	private Hashtable conNodeValueMap() {
		Hashtable StringNumMap = new Hashtable<String, Hashtable>();
		Set Nodes = AlarmReader.ALARM.getNodeNames();
		Iterator iter = Nodes.iterator();
		while (iter.hasNext()) {
			String curNodeName = (String) iter.next();
			BBNNode node = (BBNNode) AlarmReader.ALARM.getNode(curNodeName);
			BBNDiscreteValue values = (BBNDiscreteValue) node.getValues();
			Hashtable valuemap = new Hashtable<String, String>();
			Iterator itervalue = values.iterator();
			int count = 0;
			while (itervalue.hasNext()) {
				String curvalue = (String) itervalue.next();
				valuemap.put(curvalue, String.valueOf(count));
				count++;
			}
			StringNumMap.put(curNodeName, valuemap);
		}
		return StringNumMap;
	}
	
	public void findMostApprox(String[] data, String[][] datas) {
		String[] ma = null;
		double max = Double.NEGATIVE_INFINITY;
		for (int i = 0; i < datas.length; i++) {
			double temp = this.calcCosine(data, datas[i]);
			if (temp > 0.9) {
				System.out.println(temp);
			}
			if (temp > max) {
				max = temp;
				ma = datas[i];
			}
		}
		System.out.println("most approxi value" + max);
		CommonTools.outArray(ma);

	}

	/**
	 * �����������ĵ�cosine���ƶ�
	 * 
	 * @param data1
	 * @param data2
	 * @return
	 */
	public double calcCosine(String[] data1, String[] data2) {
		double uppart = 0.0;
		double downpart1 = 0.0;
		double downpart2 = 0.0;

		for(int i = 0; i < data1.length; i++)
		{
			double v1 = Integer.parseInt(data1[i]);
			double v2 = Integer.parseInt(data2[i]);
			uppart += v1 * v2;
			downpart1 += v1 * v1;
			downpart2 += v2 * v2;
		}
		downpart1 = Math.sqrt(downpart1);
		downpart2 = Math.sqrt(downpart2);

		double result = uppart / (downpart1 * downpart2);
		return result;

	}
	/**
	 * ��14412�����ݼ�ת����genile����ʽ
	 * 
	 * @param fname
	 * @return
	 */
	public String[][] tranACOBAlarm2GeNIle(String fname) {
		String[][] acobdata = this.GetDataSet();
		String[][] geniledata = new String[acobdata.length][acobdata[0].length];
		int[] order = { 18, 21, 22, 23, 15, 36, 35, 34, 33, 32, 3, 16, 17, 25,
				19, 20, 30, 11, 31, 10, 26, 28, 5, 4, 24, 0, 29, 27, 13, 6, 7,
				8, 2, 14, 9, 1, 12 };
		
		PrintWriter pw = CommonTools.getPrintWriter("c:\\", "acob.txt");
		for (int i = 0; i < order.length; i++) {
			pw.append(AlarmReader.index2nodeName.get(order[i] + 1));
			if (i != order.length - 1)
			pw.append(" ");
		}
		pw.append("\n");
		for (int i = 0; i < acobdata.length; i++) {
			for (int j = 0; j < acobdata[0].length; j++) {
				geniledata[i][j] = acobdata[i][order[j]];
			}
		}
		for (int i = 0; i < acobdata.length; i++) {
			for (int j = 0; j < acobdata[0].length; j++) {
				pw.append(geniledata[i][j]);
				pw.append(" ");
			}
			pw.append("\n");
		}
		pw.close();
		return geniledata;

	}
	public static String[][] genMissDataSetMCAR(String[][] OriginData,
			double percent) {
		Random r = new Random();
		String[][] MissData = new String[OriginData.length][OriginData[0].length];
		CommonTools.arraycopy(OriginData, MissData);
		for (int i = 0; i < OriginData.length; i++) {
			for (int j = 0; j < OriginData[0].length; j++) {
				if (r.nextDouble() < percent) {
					MissData[i][j] = "*";
				}
			}
		}
		return MissData;
	}
	/**
	 * ����miss��ȱʧ��dest���ȱʧ��
	 * 
	 * @param miss
	 * @param dest
	 */
	public static void copymiss(String[][] miss, String[][] dest) {
		for (int i = 0; i < miss.length; i++) {
			for (int j = 0; j < miss[0].length; j++) {
				if (miss[i][j].equals("*"))
					dest[i][j] = "*";
			}
		}
	}
	public static void ForwardSampling(String inputFile, String outputfile,
			int numIter) {
		int defaultMaxIteration = 3000;
		
		Runtime r = Runtime.getRuntime();
		long origfreemem = r.freeMemory();
		long freemem;

		BBNGraph graph = BBNGraph.load(inputFile);
		
		LS ls = new LS(graph);
		InferenceResult actualMarginals = ls.getMarginals();

		long origTime = System.currentTimeMillis();

		ForwardSampling dg = new ForwardSampling(graph);
		Table tuples = dg.generateData(numIter);

		freemem = origfreemem - r.freeMemory();
		long learnTime = System.currentTimeMillis();

		System.out.println("Memory needed for Forward Sampling = " + freemem);
		System.out.println("Inference time = "
				+ ((learnTime - origTime) / 1000.0));
		if (outputfile != null) {
			tuples.save(outputfile);
		} else {
			Database db = new Database();
			db.addTable(tuples);
			new ArffParser().save(System.out, db);
		}
	}

	public static int[] getOrderS2BJUT() {
		return orderS2BJUT;
	}
	
	public static int[] getOrderBJUT2S() {
		return orderBJUT2S;
	}
	public static void main(String[] args) {

		// AlarmReader.ForwardSampling("data\\alarm.xml",
		// "c:\\forwardsampling.txt", 10000);
		// AlarmReader ar = new AlarmReader("c:\\forwardsampling.txt", 10000,
		// 37);
		// String[][] data = ar.GetBNJDataSet();
		// BNGraph g = BNGraph.GetGraphStandAlarm();
		// K2 k2 = new K2(data);
		// double score = k2.calcGraphScore(g);
		// System.out.print(score);
		// AlarmReader.saveDataset(data, "c:\\data.txt");

		// AlarmReader ar = new AlarmReader("c:\\Alarm.txt", 3000, 37);
		// String[][] numdata = ar.readGeNIeDataToBjutDatanum("c:\\Alarm.txt");
		// K2 k2 = new K2(numdata);
		// double score = k2.calcGraphScore(BNGraph.GetGraphStandAlarm());
		// System.out.println(score);
		//		
		// AlarmReader ar0 = new AlarmReader("data\\alarmacob.txt", 10000, 37);
		// ar0.tranACOBAlarm2GeNIle("data\\alarmacob.txt");

		// String[][] bjutds = AlarmReader.getBJUTDS("data\\alarmacob.txt",
		// 3000);
		//		
		// String[][] gds = AlarmReader.getGDS("data\\genileacob.txt", 3000);
		// String[][] tgds = AlarmReader.tranGDS2BjutDS(gds);
		// tgds = AlarmReader.tranBjutDS2GDS(bjutds);
		//		
		// K2 k2 = new K2(gds);
		// double score = k2.calcGraphScore(BNGraph.GetGraphStandAlarm());
		// System.out.println(score);

		int[] order = AlarmReader.getOrderS2BJUT();
		int[] reverse = new int[order.length];
		
		for (int i = 0; i < reverse.length; i++) {
			int count = 0;
			for (int j = 0; j < order.length; j++) {
				if (order[j] != i)
					count++;
				else
					reverse[i] = count;
			}
		}
		CommonTools.outArray(reverse);
		
		Network net = new Network();
		net.readFile("data\\alarm.xdsl");
		for (int i = 0; i < reverse.length; i++)
			System.out.println(net.getNodeId(reverse[i]));
		
		// AlarmReader ar = new AlarmReader("data\\acob.txt", 3000, 37);
		// AlarmReader ar2 = new AlarmReader("data\\alarmacob.txt", 3000, 37);
		// String[][] data = ar.GetGeNIleDataset();
		// String[][] data2 = ar2.GetDataSet();
		// CommonTools.outArray(data[0]);
		// CommonTools.outArray(data2[0]);
		// //
		// //
		// K2 k2 = new K2(data);
		// double score = k2.calcGraphScore(BNGraph.GetGraphStandAlarm());
		// System.out.println(score);
		// CommonTools.outArray(numdata);
		// // String[][] numdata = ar.tranString2Num(data);
		// AlarmReader.saveDataset(data, "c:\\genumdata.txt");
		//
		// AlarmReader ar = new AlarmReader("data\\alarmacob.txt", 1000, 37);
		// AlarmReader ar2 = new AlarmReader("data\\alarmbnpc10k.txt", 10000,
		// 37);
		//
		// String[][] data = ar.GetDataSet();
		// String[][] data2 = ar2.GetDataSet();
		// CommonTools.outArray(data[0]);
		// ar.findMostApprox(data[0], data2);
		//		
		// ar.genGeNleEvidence("c:\\GeNleevi.txt");
		//
		System.out.print("ok");

	}
}
