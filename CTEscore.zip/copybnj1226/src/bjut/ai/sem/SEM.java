package bjut.ai.sem;

import java.io.PrintWriter;
import java.util.Hashtable;

import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.learning.acob.SingleACOB;
import bjut.ai.bn.score.EMDLScore;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;
import edu.ksu.cis.bnj.bbn.BBNGraph;

public class SEM {
	public static PrintWriter log = CommonTools.getPrintWriter("c:\\SEM", "SEMlog.txt");
	private EM em = new EM();

	public BBNGraph goSEM(String[][] missdata, int iternum) {
		BBNGraph g = null;
		BBNGraph initBN = null;
		BBNGraph BestGraph = null;
		BNGraph BestGraphBJUT = null;
		try {
			String[][] initdata = em.genInitData(missdata);
            Score k2 = new K2(initdata);
			BNGraph standard = BNGraph.GetGraphStandAlarm();// �Ƚ���
			BNGraph gk2sn = new BNGraph(K2.VEXNUM);
			SingleACOB sa = new SingleACOB(gk2sn, 0.8, 2.0, 0.6, 0.8, 30, 50,
					10, K2.TYPE.ORI, k2);
		//	gk2sn = sa.findBestBayesianNet();
			initBN = em.TranBNtoBBN(gk2sn);

			double globalBest = Double.POSITIVE_INFINITY;
			for(int i = 0; i < iternum; i++)
			{
				//����EM�Ż�
				Hashtable NewTheta = em.goEM(initBN, missdata, 0.05, 10);
				em.setThetatoGraph(initBN, NewTheta);
				
				//
				EMDLScore emdl = new EMDLScore(initBN, missdata);
				sa.setScoreMetric(emdl);
	//			gk2sn = sa.findBestBayesianNet();
			
//				System.out.println(BNGraph.CompareGraph2(standard, gk2sn));
				initBN = em.TranBNtoBBN(gk2sn);
				if(gk2sn.getScore() < globalBest)
				{
					SEM.log.println(BNGraph.CompareGraph2(standard, gk2sn));

					BestGraphBJUT = (BNGraph)gk2sn.clone();
					globalBest = gk2sn.getScore();
					BestGraph = initBN;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return BestGraph;
	}

}
